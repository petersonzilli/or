/*
  Name: dados_in.h
  Copyright: Group on Applied Optimization (at Institute of Computing,
             State University of Campinas, Brazil)
  Author: Peterson Katagiri Zilli
  Date: 26/05/05 22:05
  Descricao: Declaracao das funcoes de leitura de dados e construcao da matriz
             de distancias.
  Garantia: Nenhuma. Use sob seu proprio risco.
  Pr�-requisitos:
*/

/* prevenindo dupla inclusao acidental do header */
#ifndef DADOS_IN_H
#define DADOS_IN_H


/* constantes de controle */
#define PRINT_CLIENTES 0
#define PRINT_DMATRIX 0


/* prototipos das funcoes */

/*
 * le_dados(): le os dados do arquivo de entrada.
 * Retorna: Dados do programa, pelas referencias a variaveis!
 */
void le_dados(void);

#endif /* DADOS_IN_H */
