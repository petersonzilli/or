/*
** dados_in.c
** leitura de instancias do tipo solomon
** 
** Made by (Peterson Katagiri Zilli)
** 
** Started on  Thu Sep 22 20:40:06 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 23:08:50 2005 Peterson Katagiri Zilli
*/

/* includes */
#include <stdio.h>
#include <math.h>

/* includes locais*/
#include "dados_in.h"
#include "../globals.h"
#include "../tipos.h"
#include "../auxiliares/auxiliares.h"
#include "../memory/memalloc.h"


/********************************************************************
 * le_dados(): le os dados do arquivo de entrada.                   *
 * Retorna: Dados do programa, pelas referencias a variaveis!       *
 *                                                                  *
 * Parte do c�digo dessa fun��o por Henrique Mendes 01/02/2005      * 
 ********************************************************************/
void le_dados(void)
{

  register int i, j; /* indices auxiliares */
  FILE *dados; /* arquivo de dados da instancia no formato solomon */
  double x2maisy2; /* auxiliar para encontrar as distancias entre
		      clientes */

  dados = fopen(in_arquivo,"r");

  if (dados==NULL) {
    nrerror("Erro de Leitura de Arquivo\n");
  }

  /*
   * escaneia as 4 primeiras linhas da instancia:
   * numero de rotas no benchmark
   * distancia no benchmark
   * numero de clientes na instancia
   * capacidade de cada ve�culo
   */
  fscanf(dados,"%d[^\n]\n",&bench_rotas);
  fscanf(dados,"%f[^\n]\n",&bench_distancia);
  fscanf(dados,"%d[^\n]\n",&num_clientes);
  fscanf(dados,"%d[^\n]\n",&capacidade);

  /* aloca os vetores de dados */
  rotas = (route_t*) vvector(1,num_clientes, sizeof(route_t));
  clientes = (client_t*) vvector(0,num_clientes, sizeof(client_t));
  distancia = (prec_dist_t**) vmatrix(0,num_clientes,0,num_clientes, sizeof(prec_dist_t));


  /* leitura dos dados dos clientes */
  for(i=0; i <= num_clientes; i++) {
    fscanf(dados,"%d[^\n]\n", &(clientes[i].num));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].x));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].y));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].dem));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].t_ready));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].t_due));
    fscanf(dados,"%f[^\n]\n", &(clientes[i].s_time));
    clientes[i].b_time = 0.0;
    clientes[i].a_time = 0.0;
    clientes[i].c_dir = 0;
    clientes[i].c_esq = 0;
    clientes[i].atendido = false;
  }
  
  fclose(dados);

#if PRINT_CLIENTES
  /* imprimindo os clientes lidos */
  for(i=0; i <= num_clientes; i++) {
    printf("%5d %7.2f %7.2f %7.2f %7.2f %7.2f %7.2f\n"
	   , clientes[i].num, clientes[i].x, clientes[i].y, clientes[i].dem
	   , clientes[i].t_ready, clientes[i].t_due, clientes[i].s_time);
  }
#endif

  /* calculando distancias entre pontos */
  for(i=0; i<=num_clientes; i++) {
    for(j=0; j<=num_clientes; j++) {
      x2maisy2 = ((clientes[i].x - clientes[j].x) * (clientes[i].x - clientes[j].x))
	+ ((clientes[i].y - clientes[j].y) * (clientes[i].y - clientes[j].y));
      distancia[i][j] = (x2maisy2 == 0.0)
	? 0.0 
	: sqrt (x2maisy2);
    }
  }

#if PRINT_DMATRIX
  /* imprimindo matriz de distancias */
  for(i=0; i <= num_clientes; i++) {
    for(j=0; j <= num_clientes; j++) {
      printf("%.2f ",distancia[i][j]);
    }
    printf("\n");
  }
#endif

  return ;
}
