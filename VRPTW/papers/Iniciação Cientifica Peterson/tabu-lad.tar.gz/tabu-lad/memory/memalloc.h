/*
  Name: memalloc.h
  Copyright: Group on Applied Optimization (at Institute of Computing,
             State University of Campinas, Brazil)
  Author: Peterson Katagiri Zilli
  Date: 
  Descricao:
  Garantia: Nenhuma. Use sob seu proprio risco.
  Pr�-requisitos:
** Started on  Fri Sep 23 20:32:18 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 20:35:15 2005 Peterson Katagiri Zilli
*/

/* prevenindo dupla inclusao acidental do header */
#ifndef _MEMALLOC_H_
#define _MEMALLOC_H_

#include "../tipos.h"

/* define nul value */
#ifndef NULL
#define NULL 0
#endif

/* prototipos das funcoes */

/*
 * free_vmatrix(): permite a liberacao de vetores bi-dimensionais da mem�ria
 * alocada dinamicamente com a funcao vmatrix().
 * Retorna: Niente!
 */

void free_vmatrix(void **m, int nrl, int nrh, int ncl);


/*
 * free_vvector(): permite a liberacao de vetores uni-dimensionais da
 * mem�ria alocada dinamicamente com a funcao vvector().
 * Retorna: Niente!
 */

void free_vvector(void *v, int nl);
 

/*
 * vmatrix(): permite a aloca�ao de vetores bi-dimensionais com
 * possibilidade de definicao dos limites minimos e maximos para
 * linhas e colunas. Algo como temos em pascal, onde os vetores
 * nao necessariamente comecam do indice 0.
 * Retorna: ou ponteiro para memoria alocada ou NULL.
 */
void **vmatrix( int nrl,          /* indice da linha inicial */
                int nrh,          /* indice da linha final */
                int ncl,          /* indice da coluna inicial */
                int nch,          /* indice da coluna inicial */
                int tam);      /* tamanho do campo de dados */


/*
 * vvector(): permite a aloca�ao de vetores uni-dimensionais com
 * possibilidade de definicao dos limites minimo e maximo. Algo
 * como temos em pascal, onde os vetores nao necessariamente comecam
 * do indice 0.
 * Retorna: ou ponteiro para memoria alocada ou NULL.
 */ 
void *vvector( int nl,          /* indice da linha inicial */
               int nh,          /* indice da linha final */
               int tam);    /* tamanho do campo de dados */


#endif /* _MEMALLOC_H_ */
