/*
** Last update Fri Sep 23 20:36:34 2005 Peterson Katagiri Zilli
*/

#include <malloc.h>

/* includes locais */
#include "memalloc.h"
#include "../auxiliares/auxiliares.h"

/* corpo das funcoes */

/********************************************************************
 * free_vmatrix(): permite a liberacao de vetores bi-dimensionais   * 
 * da mem�ria alocada dinamicamente com a funcao vmatrix().         *
 * Retorna: Niente!                                                 *
 ********************************************************************/
void free_vmatrix( void **m,   /* ponteiro da estrutura a liberar */
                   int nrl,    /* indice da linha inicial */
                   int nrh,    /* indice da linhas final */
                   int ncl )   /* numero de colunas */
{
  int i;
  for (i=nrh;i>=nrl;i--) {
    free ((char *) (m[i] + ncl));
  }
  free ((char *) (m+nrl));
  
  /* certifica-se em retornar um ponteiro inv�lido */
  m = NULL;
}


/********************************************************************
 * free_vvector(): permite a liberacao de vetores uni-dimensionais  *
 * da mem�ria alocada dinamicamente com a funcao vvector().         *
 * Retorna: Niente!                                                 *
 ********************************************************************/
void free_vvector( void *v,    /* ponteiro da estrutura a liberar */
                   int nl)     /* indice da linha inicial */
{
  free ((char*) (v + nl));
  
  /* certifica-se em retornar um ponteiro inv�lido */
  v = NULL;
}


/********************************************************************
 * vmatrix(): permite a aloca�ao de vetores bi-dimensionais com     *
 * possibilidade de definicao dos limites minimos e maximos para    *
 * linhas e colunas. Algo como temos em pascal, onde os vetores     *
 * nao necessariamente comecam do indice 0.                         *
 * Retorna: ou ponteiro para memoria alocada ou NULL.               *
 ********************************************************************/
void **vmatrix( int nrl,          /* indice da linha inicial */
                int nrh,          /* indice da linha final */
                int ncl,          /* indice da coluna inicial */
                int nch,          /* indice da coluna inicial */
                int tam )         /* tamanho da struct */
{
  int i;
  void **m;
  
  m = (void **) malloc ((unsigned)(nrh-nrl+1) * tam);
  if (m == NULL) nrerror("Falha de Alocacao de Memoria 1 em vmatrix()");
  m -= nrl;
  for (i = nrl; i <= nrh; i++) {
    m[i] = (void *) malloc ((unsigned)(nch-ncl+1) * tam);
    if (m[i] == NULL) nrerror("Falha de Alocacao de Memoria 2 em vmatrix()");
    m[i] -= ncl;
  }
  return m;
}

/********************************************************************
 * vvector(): permite a aloca�ao de vetores uni-dimensionais com    *
 * possibilidade de definicao dos limites minimo e maximo. Algo     *
 * como temos em pascal, onde os vetores nao necessariamente        *
 * comecam do indice 0.                                             *
 * Retorna: ou ponteiro para memoria alocada ou NULL.               *
 ********************************************************************/                                  
void *vvector( int nl,          /* indice da linha inicial */
               int nh,          /* indice da linha final */
               int tam)         /* tamanho da struct */
{
  void *v;
  v = (void *) malloc ((unsigned)(nh-nl+1) * tam);
  if (v == NULL) nrerror("Falha de Aloca�ao de Memoria em vvector()");
  return v-nl;
}
