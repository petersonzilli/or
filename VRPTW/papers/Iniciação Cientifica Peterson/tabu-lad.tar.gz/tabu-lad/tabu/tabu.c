
#include "tabu.h"

#include "../vizinhancas/oropt/vizi_oropt.h"
#include "../vizinhancas/2optstar/vizi_2optstar.h"

#include "../constantes.h"
#include "../globals.h"

#include "../auxiliares/auxiliares.h"
#include "../memory/memalloc.h"

#include "../testset/testes.h"

#include "../route_backup/route_backup.h"

void Tabu_Search( int *b_iter )
{
  move_2opt_s move;
  int i, j;
  int **tabulist;
  int iter;
  prec_dist_t c_curr;
  prec_dist_t c_best;
  
  solution_backup_t *sol_best;
  
  int b_num_rotas;
  prec_dist_t b_distancia;
  prec_dist_t distancia_atual;
  
  b_distancia = DIST_INFINITO;  
  b_num_rotas = SINT_INFINITO;
  /*
  b_distancia = retorna_distancia();  
  b_num_rotas = num_rotas;
  */
  
  c_curr = c_best = DIST_INFINITO;
  /*
  c_curr = c_best = b_distancia;
  distancia_atual = b_distancia;
  */
  
  iter = *b_iter = 0;
  
  sol_best = (solution_backup_t *) vvector(0,0,sizeof(solution_backup_t));
  
  tabulist = (int **) vmatrix(1,num_clientes,1,num_clientes,sizeof(int));
    
  for (i=1;i<=num_clientes;i++)
    for (j=1;j<=num_clientes;j++)
      tabulist[i][j] = 0;
  
  solution_backup(sol_best,0);
  
   while (iter < TABU_MAX_ITER) {
    iter++;
    vizi_2opt_s_best_move_tabu( &move, c_curr, c_best, tabulist, iter );
    
    if (move.custo == DIST_INFINITO) continue;
        
    vizi_2opt_s_exec_tabu( move.r1, move.indx_c1, move.r2, move.indx_c2, &tabulist, iter );
    c_curr += move.ddist;
    distancia_atual += move.ddist;
 
    
    /* oropt */
    {       
      move_oropt moveOr;
      vizi_oropt_best_move_rota(move.r1, &moveOr);
      while (moveOr.custo < 0.0) {
        vizi_oropt_exec(move.r1, moveOr.c10, moveOr.c11, moveOr.c20, moveOr.c21, moveOr.c30, moveOr.c31);
        c_curr += moveOr.ddist;
        distancia_atual += moveOr.ddist;
        vizi_oropt_best_move_rota(move.r1, &moveOr);
      }
      
      vizi_oropt_best_move_rota(move.r2, &moveOr);
      while (moveOr.custo < 0.0) {
        vizi_oropt_exec(move.r2, moveOr.c10, moveOr.c11, moveOr.c20, moveOr.c21, moveOr.c30, moveOr.c31);
        c_curr += moveOr.ddist;
        distancia_atual += moveOr.ddist;
        vizi_oropt_best_move_rota(move.r2, &moveOr);
      }
    }
    
    if (c_curr < c_best) {
      b_num_rotas = num_rotas;
      *b_iter = iter;
      b_distancia = distancia_atual;
      c_best = c_curr;
      solution_backup(sol_best,0);
    }
    
     
  }
  
  solution_restore(sol_best, 0);

  return;
}
