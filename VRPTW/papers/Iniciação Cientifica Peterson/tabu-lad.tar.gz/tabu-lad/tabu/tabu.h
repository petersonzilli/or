
/* prevenindo dupla inclusao */
#ifndef TABU_H_
#define TABU_H_

void Tabu_Search( int *b_iter );

#endif /* _TABU_H_*/
