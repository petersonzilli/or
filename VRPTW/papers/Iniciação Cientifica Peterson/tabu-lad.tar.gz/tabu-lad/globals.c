
/*
** globals.c
** 
** Made by (Peterson Katagiri Zilli)
** 
** Started on  Fri Sep 23 21:44:45 2005 Peterson Katagiri Zilli
** Last update Sat Sep 24 01:51:42 2005 Peterson Katagiri Zilli
*/

#include "constantes.h"
#include "tipos.h"

/* variaveis leitura */
char *in_arquivo;
int bench_rotas;
prec_dist_t bench_distancia;

int capacidade;
int num_clientes;
int num_rotas;

route_t *rotas;
client_t *clientes;
prec_dist_t **distancia;

/* variaveis de contrucao */
int num_clientes_atendidos;
int sementes[NUM_SEED];
int *lista_cli_prox;
int dist_cli_max;
int param_ord_seed;
float param_alfa1;
float param_alfa3;
float param_dist_granular;
int lista_cli_prox_num_cli; /* numero na lista de clientes proximos */
solution_backup_t*  backup_solutions;
int num_backup_solutions;

