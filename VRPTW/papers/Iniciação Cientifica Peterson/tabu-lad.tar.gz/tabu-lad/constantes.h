
/* prevenindo dupla inclusao */
#ifndef CONSTANTES_H_
#define CONSTANTES_H_

/* constantes */
#define DIST_NEGATIVA (-1.0)
#define DIST_INFINITO (9999999.0)
#define SINT_INFINITO (32000)


/****************************************************************************************/
/* parametros das vizinhancas */

/* parametros vizinhancas */
#define VIZI_PESO_ROTA (1000)


/* parametros da vizinhanca oropt*/
#define OROPT_ALFA2 (0)
#define OROPT_ALFA3 (0)


/* parametros tabu */
#define TABU_MAX_ITER (5000)
#define TABU_TENURE ((int) num_rotas / 2 )
/****************************************************************************************/





/* parametros da construcao do braysy */

/** sementes **/
#define CONS_SEM_CRIA_PC_SC (1) /* 1 para habilitar criacao das sementes pc e sc */
#define NUM_SEED (25) /* numero de sementes */
#define PARAM_SEED_ORD (3) /* numero de ordenacoes de sementes */

/** parametros **/
#define PARAM_INCREMENTS_DIST_GRANULAR (0.2)
#define PARAM_DIST_GRANULAR_MIN (0.4)
#define PARAM_DIST_GRANULAR_MAX (1.0)
#define PARAM_DIST_GRANULAR (param_dist_granular)

#define PARAM_ALFA1 (param_alfa1)
#define PARAM_INCREMENTS_ALFA1 (0.2)
#define PARAM_ALFA1_MIN (0.2)
#define PARAM_ALFA1_MAX (1.0)

#define PARAM_ALFA3 (param_alfa3)
#define PARAM_INCREMENTS_ALFA3 (0.2)
#define PARAM_ALFA3_MIN (0.0)
#define PARAM_ALFA3_MAX (1.8)

#define PDG ((int)((PARAM_DIST_GRANULAR_MAX - PARAM_DIST_GRANULAR_MIN) / PARAM_INCREMENTS_DIST_GRANULAR +1))
#define PA3 ((int)((PARAM_ALFA3_MAX - PARAM_ALFA3_MIN) / PARAM_INCREMENTS_ALFA3 +1))
#define PA1 ((int)((PARAM_ALFA1_MAX - PARAM_ALFA1_MIN) / PARAM_INCREMENTS_ALFA1 +1))
#define POS ((int)(PARAM_SEED_ORD))

#define NUM_TOTAL_INITIAL_SOLUTIONS_BRAYSY (POS * PA3 * PA1 * PDG)


#endif /* CONSTANTES_H_ */
