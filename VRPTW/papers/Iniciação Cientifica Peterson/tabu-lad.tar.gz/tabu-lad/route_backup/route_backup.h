
/* preventing double inclusion */
#ifndef ROUTE_BACKUP_H_
#define ROUTE_BACKUP_H_

#include "../tipos.h"

void solution_backup(solution_backup_t *vec_solutions, int num_initial_solutions);

void solution_backup_print(solution_backup_t *vec_solutions, int num_backup_solutions);

void solution_restore(solution_backup_t *vec_solutions, int num_restore);

void solution_free_memory(solution_backup_t *vec_solutions, int num_free);

#endif /* _ROUTE_BACKUP_H_*/
