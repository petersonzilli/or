
#include <stdio.h>

#include "../globals.h"
#include "../auxiliares/auxiliares.h"
#include "../memory/memalloc.h"

#include "../testset/testes.h"

#include "route_backup.h"

/* salva rota no backup */
void solution_backup(solution_backup_t *vec_solutions, int num_initial_solutions)
{
  volatile int i, j, indxcli, indxrot;     /* contadores auxiliares */
  ap_cliente_t ap_cli_aux; /* apontador auxiliar para clientes */
  
  vec_solutions[num_initial_solutions].rotas = (int*) vvector(0,num_clientes, sizeof(int));
  vec_solutions[num_initial_solutions].clientes = (int*) vvector(0,num_clientes, sizeof(int));
  
  indxcli = indxrot = 0;
  
  vec_solutions[num_initial_solutions].num_rotas = num_rotas;
  vec_solutions[num_initial_solutions].distancia = retorna_distancia();
  for(i=1; i<= num_clientes; i++) {
    if (rotas[i].num_clientes <1) continue;
    ap_cli_aux = rotas[i].inicio;
    vec_solutions[num_initial_solutions].rotas[indxrot++] = indxcli;
    vec_solutions[num_initial_solutions].clientes[indxcli] = ap_cli_aux;
    indxcli++;
    for (j=1; j < rotas[i].num_clientes; j++) {
      ap_cli_aux = clientes[ap_cli_aux].c_dir;
      vec_solutions[num_initial_solutions].clientes[indxcli] = ap_cli_aux;
      indxcli++;
    }
  }
  for (i=num_rotas;i<num_clientes;i++) vec_solutions[num_initial_solutions].rotas[i]=0;
}

  
/* imprime rotas no backup */
void solution_backup_print(solution_backup_t *vec_solutions, int num_backup_solutions)
{
  volatile int i, j;
  for (i=0; i < num_backup_solutions; i++) {
    printf("clientes: ");
    for (j=0; j<num_clientes; j++) {
      printf("%3d ",vec_solutions[i].clientes[j]);
    }
    printf("\n");
    printf("rotas: ");
    for (j=0; j<num_clientes; j++) {
      printf("%3d ", vec_solutions[i].rotas[j]);
    }
    printf("\n\n");
  }
}

/* carrega rota (da posicao num_restore) do backup para a solucao atual */
void solution_restore( solution_backup_t *vec_solutions, int num_restore )
{
  volatile int i, j, tam_rota;
  zera_solucao();
  /* para todas as rotas menos a ultima */
  for (i=0; i < (vec_solutions[num_restore].num_rotas); i++) {
    /* calcula o tamanho da rota */
    tam_rota = (i == (vec_solutions[num_restore].num_rotas - 1))
               ? num_clientes - vec_solutions[num_restore].rotas[i]
               : vec_solutions[num_restore].rotas[(i+1)] - vec_solutions[num_restore].rotas[i];

    /* seta inicio da rota */
    rotas[i+1].inicio = (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i])]);
    rotas[i+1].num_clientes = tam_rota;

    /* seta final da rota */
    rotas[i+1].fim = (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + tam_rota - 1)]);
    
    /* coloca o primeiro cliente na solucao atual */
    clientes[(vec_solutions[num_restore].clientes[vec_solutions[num_restore].rotas[i]])].c_esq 
      = 0;
    clientes[(vec_solutions[num_restore].clientes[vec_solutions[num_restore].rotas[i]])].c_dir 
      = (tam_rota == 1)
        ? 0
        : (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + 1)]);      

    for (j = 1; j < (tam_rota-1) ; j++) {
      clientes[(vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + j)])].c_esq
	= (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + j - 1)]);
      clientes[(vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + j)])].c_dir
	= (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + j + 1)]);
    }

    /* coloca o ultimo cliente na solucao atual */
    clientes[(vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + tam_rota - 1)])].c_esq 
      = (tam_rota==1)
        ? 0
        : (vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + tam_rota - 2)]);
    
    clientes[(vec_solutions[num_restore].clientes[(vec_solutions[num_restore].rotas[i] + tam_rota - 1)])].c_dir = 0;

    atualiza_rota(i+1);
  }
  
  /* carrega o numero de rotas */
  num_rotas = vec_solutions[num_restore].num_rotas;
}

void solution_free_memory(solution_backup_t *vec_solutions, int num_free)
{
  /* TODO: rotina de liberacao de memoria das solucoes backup que nao sao mais utilizadas */
  nrerror("> void solution_free_memory(solution_backup_t *vec_solutions, int num_free) not implemented yet.");
}


