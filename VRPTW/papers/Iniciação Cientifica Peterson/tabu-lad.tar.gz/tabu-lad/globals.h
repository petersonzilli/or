/*
** globals.h
** 
** Made by Peterson Katagiri Zilli
** 
** Started on  Fri Sep 23 21:45:07 2005 Peterson Katagiri Zilli
** Last update Sat Sep 24 01:30:39 2005 Peterson Katagiri Zilli
*/

#ifndef GLOBALS_H_
#define GLOBALS_H_

#include "constantes.h"
#include "tipos.h"

/* variaveis de leitura */
extern char *in_arquivo;
extern int bench_rotas;
extern prec_dist_t bench_distancia;

extern int capacidade;
extern int num_clientes;
extern int num_rotas;

extern route_t *rotas;
extern client_t *clientes;
extern prec_dist_t **distancia;

/* variaveis de construcao*/
extern int num_clientes_atendidos;
extern int sementes[NUM_SEED];
extern int *lista_cli_prox;
extern int dist_cli_max;
extern int param_ord_seed;
extern float param_alfa1;
extern float param_alfa3;
extern float param_dist_granular;
extern int lista_cli_prox_num_cli; /* numero na lista de clientes proximos */
extern solution_backup_t *  backup_solutions; 
extern int num_backup_solutions;

#endif 	    /* !GLOBALS_H_ */
