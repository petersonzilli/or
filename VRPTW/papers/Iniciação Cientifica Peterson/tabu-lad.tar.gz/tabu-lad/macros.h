/*
** macros.h
**  macros usados na heuristica tabu-lad
** 
** Made by (Peterson Katagiri Zilli)
** 
** Started on  Thu Sep 22 17:35:01 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 20:33:32 2005 Peterson Katagiri Zilli
*/

/* prevenindo dupla inclusao */
#ifndef MACROS_H_
#define MACROS_H_

/* macros */
#define MAX(X,Y)    ( (X) > (Y) ? (X) : (Y) )
#define MIN(X,Y)    ( (X) < (Y) ? (X) : (Y) )

#endif /* _MACROs_H_ */
