/*
** tipos.h
** tipos usados na heuristica tabu-lad 
** 
** Made by (Peterson Katagiri Zilli)
** 
** Started on  Thu Sep 22 17:11:06 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 20:32:18 2005 Peterson Katagiri Zilli
*/


/* preventing double inclusion */
#ifndef _TIPOS_H_
#define _TIPOS_H_

/* Boolean enum */
#ifndef BOOLEAN
#define BOOLEAN
typedef enum {false, true} Boolean;
#endif

/* Null value */
#ifndef NULL
#define NULL (0)
#endif

/* tipo usado para dados de precisao */
typedef double prec_dist_t; /* precisao para distancia */
typedef float prec_time_t;  /* precisao para tempo*/
typedef float prec_dem_t;   /* precisao para demanda */

/* apontador para um cliente */
typedef unsigned int ap_cliente_t;

/* estrutura de um cliente */
typedef struct client {
  int num;               /* numero do cliente */
  float x;               /* posi��o x do cliente */
  float y;               /* posi��o y do cliente */
  prec_dem_t dem;        /* demanda do cliente */
  prec_time_t t_ready;   /* limite inferior da Janela de Tempo */
  prec_time_t t_due;     /* limite superior da Janela de Tempo */
  prec_time_t s_time;    /* tempo de servico */
  prec_time_t b_time;    /* tempo de inicio de atendimento na rota */
  prec_time_t a_time;    /* tempo de chegada no cliente atual */
  ap_cliente_t c_dir;    /* inteiro "apontador" para o cliente da direita */
  ap_cliente_t c_esq;    /* inteiro "apontador" para o cliente da esquerda */
  Boolean atendido;      /* flag de atendimento do cliente */
} client_t;

/* estrutura de uma rota */
typedef struct route {
  int num_clientes;      /* numero de clientes na rota atual */
  prec_dem_t demanda;    /* demanda atual da rota */
  prec_time_t espera;    /* tempo de espera atual da rota */
  prec_dist_t distancia; /* distancia atual da rota */
  ap_cliente_t inicio;   /* apontador para o primeiro cliente */
  ap_cliente_t fim;      /* apontador para o final cliente */
} route_t;

/* estrutura de uma solucao backup */
typedef struct solution_backup {
  int num_rotas;         /* numero de rotas da solucao no backup */
  prec_dist_t distancia;       /* distancia total da solucao backup */
  int *rotas;            /* numero de inicio das rotas no vetor de clientes */
  int *clientes;         /* ordem dos clientes nas rotas */
} solution_backup_t;

#endif /* _TIPOS_H_ */
