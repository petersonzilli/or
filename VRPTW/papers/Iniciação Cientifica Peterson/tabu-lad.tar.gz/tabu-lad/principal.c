/*
** principal.c
** principal do projeto tabu-lad
** 
** Made by (Peterson Katagiri Zilli)
** 
** Started on  Fri Sep 23 21:11:19 2005 Peterson Katagiri Zilli
** Last update Sat Sep 24 01:51:43 2005 Peterson Katagiri Zilli
*/

#include <stdio.h>

#include "constantes.h"
#include "principal.h"
#include "globals.h"
#include "leitura/dados_in.h"
#include "auxiliares/time.h"
#include "construcao/braysy/construcao.h"
#include "tabu/tabu.h"

struct rusage ruse;

int main(int argc, char **argv)
{
  int b_iter_tabu;
  double t0, t1;

#define desabilita (0)
#ifdef desabilita
  /* verifica o uso do programa */
  if (argc!=2) {
    printf("Uso: > %s nome_do_arquivo_de_dados\n", argv[0]);
    return 1;
  }
 
  /*printf("-- inicio --\n");
  t0 = CPUTIME(ruse); 
  */
  /* le os dados da instancia */
  in_arquivo = argv[1];  
  le_dados();

  /*
  t1 = CPUTIME(ruse);
  printf("CPU time para leitura de Instancia: %f secs.\n", t1-t0);
  */

  /* construcao */
  Const_Braysy();

  /* busca tabu */

  b_iter_tabu = 0;

  solution_restore(backup_solutions, 1);

  /*
  printf("Solução A Aplicar Tabu Search.\n");
    imprime_rotas();
    TSTtw();
    TSTdistancia();
    TSTcapacidade();
  */

  Tabu_Search(&b_iter_tabu);

  /*
  printf("Aplicado tabu search: %d (iteracoes).\n", b_iter_tabu);
  */
  printf ("%d\n",num_rotas);
    imprime_rotas();
  /*
    TSTtw();
    TSTdistancia();
    TSTcapacidade();
  printf("--  fim   --\n");
  */

#endif



  return 0;
}
