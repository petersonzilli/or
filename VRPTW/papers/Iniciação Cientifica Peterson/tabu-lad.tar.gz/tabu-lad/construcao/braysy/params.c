
#include "../../constantes.h"

float modulo (int a, int b)
{
  return (a % b);
}

/* Gera parametros de acordo com o numero da solucao a ser criada */
void params_generate(int num_initial_solutions, int *param_ord_seed, float *param_alfa1, float *param_alfa3, float *param_distancia_granular) {

  float aux;
  
  aux = num_initial_solutions;
  *param_distancia_granular = modulo(aux,PDG) * PARAM_INCREMENTS_DIST_GRANULAR + PARAM_DIST_GRANULAR_MIN;
  
  aux = (aux-modulo(aux,PDG)) / PDG;
  *param_alfa3 = modulo(aux,PA3) * PARAM_INCREMENTS_ALFA3 + PARAM_ALFA3_MIN;
  
  aux = (aux-modulo(aux,PA3)) / PA3;
  *param_alfa1 = modulo(aux,PA1) * PARAM_INCREMENTS_ALFA1 + PARAM_ALFA1_MIN;
  
  aux = (aux-modulo(aux,PA1)) / PA1;
  *param_ord_seed = modulo(aux,POS);
 
  return;
}
