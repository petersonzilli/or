
/* prevenindo dupla inclusao acidental do header */
#ifndef CONST_INSERCAO_H_
#define CONST_INSERCAO_H_

/* includes locais */
#include "../../tipos.h"

/*
 * ins_executa(); executa a insercao de um cliente nao roteado 'c' na posicao
 *  'i' da rota 'r' * Retorna: void.
 */
void ins_executa( int r, int cli_anterior, int c );

/*
 * ins_avalia_distancia ();
 * Retorna: o diferencial da distancia da insercao do cliente 'cli' na posicao
 *  'pos' da rota 'r'
 */                          
prec_dist_t ins_avalia_distancia( int r, int cli_anterior, int cli );

/*
 * ins_avalia_tempo_espera();
 * Retorna: o diferencial de tempo de espera da insercao do cliente 'cli' na
 * posicao 'pos' da rota 'r'
 * eh possivel na otica da janela de tempo.
 */
float ins_avalia_tempo_espera( int r, int cli_anterior, int cli );

/*
 * ins_avalia_TW();
 * Retorna: 'true' se a insercao do cliente 'cli' na posicao 'pos' da rota 'r' 
 * eh possivel na otica da janela de tempo.
 */
Boolean ins_avalia_TW(int r, int cli_anterior, int cli);


/*
 * ins_avalia_capacidade();
 * Retorna: 'true' se a insercao do cliente 'c' na rota 'r' eh possivel na otica
 *  da capacidade.
 */
Boolean ins_avalia_capacidade(int r, int c);


/*
 * ins_prox_cliente();
 * Retorna: o melhor cliente e a melhor posicao para se inserir na rota em
 *  construcao
 */
void ins_prox_cliente( int r,
                       int *cli,
                       int *cli_anterior,
                       prec_dist_t *delta_distancia,
                       prec_time_t *delta_tespera,
                       prec_dist_t *custo );

/*
 * ins_melhor_insercao_na_rota();
 * Retorna: a melhor insercao do cliente cli na rota em construcao
 */
void ins_melhor_insercao_na_rota( int r,
                                  int cli,
                                  int *cli_anterior,
                                  prec_dist_t *delta_distancia,
                                  prec_time_t *delta_tespera,
                                  prec_dist_t *custo );

/*
 * ins_avalia_posicao();
 * Retorna: o custo da insercao do cliente 'cli' na posicao 'pos'
 */
void ins_avalia_posicao( int r,
                         int cli,
                         int cli_anterior,
                         prec_dist_t *delta_distancia,
                         prec_time_t *delta_tespera,
                         prec_dist_t *custo );

#endif /* _CONST_INSERCAO_H_ */
