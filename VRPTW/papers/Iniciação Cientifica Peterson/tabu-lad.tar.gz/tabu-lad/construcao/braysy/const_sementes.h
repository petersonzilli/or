/*
** first release 07/jul/2005 00:13
** Last update Sat Sep 24 01:12:51 2005 Peterson Katagiri Zilli
*/

#ifndef CONST_SEMENTES_H_
#define CONST_SEMENTES_H_

/* includes locais */
#include "../../constantes.h"
#include "../../tipos.h"

/*
 * sem_cria_sementes(); Aloca e popula o vetor de sementes.
 * Retorna: nada
 */
void sem_cria_sementes( void );

/*
 * sem_cli_eh_semente(); verifica se cliente esta no vetor de
 *  sementes.
 * Retorna: 'true' se cliente esta no vetor de sementes, 'false' caso contrario
 */
Boolean sem_cli_eh_semente( int cli );

/*
 * sem_cli_mais_dist_dep();
 * Retorna: o cliente mais distante do deposito.
 */
int sem_cli_mais_dist_dep( void );

/*
 * sem_cli_mais_dist_ant();
 * Retorna: o cliente mais distante de todas as sementes que populam o vetor de
 *  sementes.
 */
int sem_cli_mais_dist_ant( void );

/*
 * sem_cli_prox_dois_clientes();
 * Retorna: o cliente mais proximo de dois clientes 'c1' e 'c2'.
 */
int sem_cli_prox_dois_clientes( int c1, int c2 );

/*
 * sem_seleciona_semente();
 * Retorna: o cliente mais distante de toas as sementes que populam o vetor de
 *  sementes.
 */
int sem_seleciona_semente( void );

/*
 * sem_ordena_proximidade(); ordena o vetor de sementes por proximidade.
 * Retorna: void
 */
void sem_ordena_proximidade( void );

/*
 * sem_ordena_dist_anterior(); ordena o vetor de sementes por maior distancia da
 *  semente anterior.
 * Retorna: void
 */
void sem_ordena_dist_anterior();

/*
 * sem_ordena_dist_anteriores(); ordena o vetor de sementes por maior distancia
 * de todas as sementes anteriores.
 * Retorna: void
 */
void sem_ordena_dist_anteriores();

/*
 * sem_ordena_var_horario(); ordena o vetor de sementes por varredura de angulos, no sentido horario.
 * Retorna: void
 */
void sem_ordena_var_horario( void );

/*
 * sem_ordena_var_antihorario(); ordena o vetor de sementes por varredura de angulos, no sentido horario.
 * Retorna: void
 */
void sem_ordena_var_antihorario( void );

/*
 * sem_imprime_vetor(); imprime o vetor de sementes.
 * Retorna: void
 */
void sem_imprime_vetor( void );

#endif /* _CONST_SEMENTES_H_ */
