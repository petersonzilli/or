
#include "../../constantes.h"

#include "../../globals.h"
#include "../../memory/memalloc.h"

#include "../../testset/testes.h"

#include "const_init_solution.h"
#include "const_sementes.h"
#include "params.h"

#include "../../route_backup/route_backup.h"
#include "make_rb.h"

#include "../../vizinhancas/oropt/vizi_oropt.h"

void Const_Braysy( void )
{
  register int num_initial_solutions, i;
  ap_cliente_t aux_cli;

  /* distancia que define dois clientes vizinhos */
  dist_cli_max = 0.0;

  aux_cli  = sem_cli_mais_dist_dep();
  for (i=0;  i<num_clientes; i++) {
     if (dist_cli_max < distancia [aux_cli][i]) {
	dist_cli_max = distancia[aux_cli][i];
     }
  }


  /* seed creation */
  sem_cria_sementes();

  /* aloca espaco para as solucoes backup */
  backup_solutions =
    (solution_backup_t *) vvector(0,NUM_TOTAL_INITIAL_SOLUTIONS_BRAYSY,sizeof(solution_backup_t));
  
  /* fix initial variables values */
  num_initial_solutions = 0;
  num_backup_solutions = 0;

  while (num_initial_solutions < NUM_TOTAL_INITIAL_SOLUTIONS_BRAYSY) {

  /*==================================================================================================*/
  /*
   * Step 1: Repeat steps 2 and 3 using all the parameter falues within the specified limits. Store the create solutions
   * Step 2: Use sequential insertion heuristic to create an initial solution
   * Step 3: Repeat route elimination procedure until no more routes can be eliminated
   */

    /* generate new params to initial solution construction */
    params_generate(num_initial_solutions, &param_ord_seed, &param_alfa1, &param_alfa3, &param_dist_granular);

  
    /* create actual initial solution itself */
   const_init_solution(); 

    /* eliminate routes form actual solution */
    /*eliminate_routes_from_solution();*/


    /* otimize solution with descendent heuristics */
    {
      volatile int r1;
      move_oropt moveOr;
      for (r1 = 0; r1 <= num_rotas; r1++) {
	      vizi_oropt_best_move_rota(r1, &moveOr);
	      while (moveOr.custo < 0.0) {
	        vizi_oropt_exec(r1, moveOr.c10, moveOr.c11, moveOr.c20, moveOr.c21, moveOr.c30, moveOr.c31);
	        vizi_oropt_best_move_rota(r1, &moveOr);
	      }
      }
    }

    /* backup actual solution to vec_solutions (in position num_initial_solutions) */
    solution_backup( backup_solutions, num_initial_solutions );
    
    /* teste de cada solucao */
    /*imprime_rotas();*/
    TSTtw();
    TSTdistancia();
    TSTcapacidade();
    /**/

    num_initial_solutions++;
  }

  /* uptating the number of backup solutions */
  num_backup_solutions = NUM_TOTAL_INITIAL_SOLUTIONS_BRAYSY;

  /*==================================================================================================*/
  /*
   * Step 4: Identify all the created solutions with the smallest
   * number of routes and insert them into set RB
   */

  make_rb( backup_solutions, &num_backup_solutions);

  /*==================================================================================================*/

  return;
}
