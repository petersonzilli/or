
/* prevenindo dupla inclusao acidental do header */
#ifndef CONST_LISTA_CLI_PROX_H_
#define CONST_LISTA_CLI_PROX_H_

/* includes locais */
#include "../../tipos.h"

/*
 * lista_cli_prox_esta_na_lista();
 * Retorna: retorna se o cliente esta na lista de clientes proximos da rota
 *  atual
 */
Boolean lista_cli_prox_esta_na_lista( int cli );

/*
 * lista_cli_prox_atualiza(); atualiza lista de clientes proximos da rota atual
 *  com a adicao do novo cliente 'cli'
 * Retorna: void
 */
void lista_cli_prox_atualiza( int cli );

/*
 * lista_cli_prox_apaga(): apaga cliente 'cli' da lista de clientes proximos da
 *  rota atual
 * Retorna: void
 */
void lista_cli_prox_apaga( int cli );

/*
 * lista_cli_prox_imprime_vetor(); imprime o vetor de sementes.
 * Retorna: void
 */
void lista_cli_prox_imprime_vetor( void );

#endif /* _CONST_LISTA_CLI_PROX_H_ */
