
/* prevenindo dupla inclusao */
#ifndef MAKE_RB_H_
#define MAKE_RB_H_

#include "../../tipos.h"

/* defines */
#define ORDENA_ROTAS 1
#define ORDENA_DISTANCIA 1

/* functions prototypes */
void make_rb(solution_backup_t *vec_solutions, int *num_backup_solutions);

#endif /* MAKE_RB_H_ */
