
/* prevenindo dupla inclusao */
#ifndef CONST_INIT_SOLUTION_H_
#define CONST_INIT_SOLUTION_H_

void const_init_solution( void );

#endif /* _CONST_INIT_SOLUTION_H_ */
