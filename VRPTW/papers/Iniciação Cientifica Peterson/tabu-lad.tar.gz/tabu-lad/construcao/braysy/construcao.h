
/* prevenindo dupla inclusao */
#ifndef CONSTRUCAO_BRAYSY_H_
#define CONSTRUCAO_BRAYSY_H_

void Const_Braysy( void );

#endif /* _CONSTRUCAO_BRAYSY_H_*/
