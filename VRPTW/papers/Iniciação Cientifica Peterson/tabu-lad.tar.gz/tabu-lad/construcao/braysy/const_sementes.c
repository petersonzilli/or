/*
** first release: 07/jul/2005 00:15 - desmembrado do arquivo fonte unico das rotinas de construcao 
** Last update Sat Sep 24 01:17:24 2005 Peterson Katagiri Zilli
*/

#include <stdlib.h> /* qsort */
#include <stdio.h> /* printf */

#include "../../constantes.h"
#include "const_sementes.h"

/* variaveis glogais */
#include "../../globals.h"

/* variaveis a nivel de modulo */
static int num_sementes_no_vetor;

/* corpo das funcoes */

/*
 * sem_cria_sementes(); Aloca e popula o vetor de sementes.
 * Retorna: nada
 */
void sem_cria_sementes( void )
{

#if CONS_SEM_CRIA_PC_SC
  register int i;
#endif

  num_sementes_no_vetor = 0;

#if CONS_SEM_CRIA_PC_SC
  /* inserindo o conjunto PC */
  sementes[num_sementes_no_vetor++] = sem_cli_mais_dist_dep();
  
  for(i = 0; i < 3 && i < num_clientes; i++)
    sementes[num_sementes_no_vetor++] = sem_cli_mais_dist_ant();

  /* inserindo o conjunto SC */
  if (num_sementes_no_vetor < num_clientes)
    sementes[num_sementes_no_vetor++] = sem_cli_prox_dois_clientes(1, 3);
  if (num_sementes_no_vetor < num_clientes)
    sementes[num_sementes_no_vetor++] = sem_cli_prox_dois_clientes(1, 4);
  if (num_sementes_no_vetor < num_clientes)
    sementes[num_sementes_no_vetor++] = sem_cli_prox_dois_clientes(2, 3);
  if (num_sementes_no_vetor < num_clientes)
    sementes[num_sementes_no_vetor++] = sem_cli_prox_dois_clientes(2, 4);
#endif

  /* inserindo o conjunto T */
  while (num_sementes_no_vetor < NUM_SEED && num_sementes_no_vetor < num_clientes){
    sementes[num_sementes_no_vetor++] = sem_cli_mais_dist_dep();
  }
  
  return;
}


/*
 * sem_cli_eh_semente(); verifica se cliente esta no vetor de sementes, para
 * funcoes internas! Verifica somente at� a ultima semente inserida.
 * Retorna: 'true' se cliente esta no vetor de sementes, 'false' caso contrario
 */
Boolean sem_cli_eh_semente( int cli )
{
  register int i;

  for(i = 0; i < num_sementes_no_vetor && sementes[i] != cli; i++);
  if(i < num_sementes_no_vetor) return true;
 
  return false;
}


/*
 * sem_cli_mais_dist_dep();
 * Retorna: o cliente que nao eh semente mais distante do deposito.
 */
int sem_cli_mais_dist_dep( void )
{
  register int i;
  prec_dist_t ddistancia = DIST_NEGATIVA;
  int dcliente = 0;
  
  for(i = 1; i <= num_clientes; i++)
    if (ddistancia < distancia[0][i] && !sem_cli_eh_semente(i)) {
      ddistancia = distancia[0][i];
      dcliente = i;
    }
    
  return dcliente;
}


/*
 * sem_cli_mais_dist_ant();
 * Retorna: o cliente mais distante de todas as sementes que populam o vetor de
 *  sementes.
 */
int sem_cli_mais_dist_ant( void )
{
  register int i, j;
  prec_dist_t ddistancia = DIST_NEGATIVA;
  int dcliente = 0;
  prec_dist_t soma_distancia;
  
  for(i=1; i<= num_clientes; i++) {
    soma_distancia = 0.0;
    for(j = 0; j < num_sementes_no_vetor; j++)
      soma_distancia += distancia[sementes[j]][i];
    if (ddistancia < soma_distancia && !sem_cli_eh_semente(i)) {
      ddistancia = soma_distancia;
      dcliente = i;
    }
  }
  
  return dcliente;
}


/*
 * sem_cli_prox_dois_clientes();
 * Retorna: o cliente mais proximo de dois clientes 'c1' e 'c2'.
 */
int sem_cli_prox_dois_clientes( int c1, int c2 )
{
  register int i;
  prec_dist_t pdistancia = DIST_INFINITO;
  int pcliente = 0;
  prec_dist_t soma_distancia;
  
  for(i = 1; i <= num_clientes; i++) {
    soma_distancia = distancia[c1][i] + distancia[c2][i];
    if (pdistancia > soma_distancia && !(sem_cli_eh_semente(i))) {
      pdistancia = soma_distancia;
      pcliente = i;
    }
  }
  
  return pcliente;
}


/*
 * sem_seleciona_semente();
 * Retorna: o cliente mais distante de toas as sementes que populam o vetor de
 *  sementes.
 */
int sem_seleciona_semente( void )
{
  register int i;
  int semente;
  
  /* corre ate a primeira semente livre... */
  for (i = 0; i < num_sementes_no_vetor && clientes[sementes[i]].atendido != false; i++);
  
  /* se ainda existem sementes livres entao */
  if (i < num_sementes_no_vetor) {
    semente = sementes[i];

  /* senao seleciona algum cliente nao atendido por ordem de indice */
  } else {
    for(i = 1;
        i <= num_clientes && clientes[i].atendido != false;
        i++);
    semente = i;
  }
  
  return semente;
}


/*
 * sem_ordena_proximidade(); ordena o vetor de sementes por proximidade.
 * Retorna: void
 */
void sem_ordena_proximidade( void )
{
  register int i, j;
  int mincli, auxcli;
  prec_dist_t mindist, auxdist;

  /* para cada posicao de i+1 at� NS-1... */
  for (i=0 ; i<(num_sementes_no_vetor-2); i++) {
    mindist = DIST_INFINITO;
    mincli = i+1;
    /* avalie o melhor clientes... */
    for (j=i+1; j<num_sementes_no_vetor; j++) {
      auxdist = distancia[sementes[i]][sementes[j]];
      if (auxdist < mindist) {
        mindist = auxdist;
        mincli = j;
      }
    }
    /* e troque a semente mais proxima com a semente i+1 */
    auxcli = sementes[i+1];
    sementes[i+1] = sementes[mincli];
    sementes[mincli] = auxcli;
  }
  return;
}


/*
 * sem_ordena_dist_anterior(); ordena o vetor de sementes por maior distancia da
 *  semente anterior.
 * Retorna: void
 */
void sem_ordena_dist_anterior()
{
  register int i, j;
  int mincli, auxcli;
  prec_dist_t mindist, auxdist;

  /* para cada posicao de i+1 ate NS-1*/
  for (i=0 ; i<(num_sementes_no_vetor-2); i++) {
    mindist = 0;
    mincli = i+1;
    /* avalie o melhor cliente */
    for (j=i+1; j<num_sementes_no_vetor; j++) {
      auxdist = distancia[sementes[i]][sementes[j]];
      if (auxdist > mindist) {
        mindist = auxdist;
        mincli = j;
      }
    }
    /* troque o cliente i+1 com o melhor cliente avaliado */
    auxcli = sementes[i+1];
    sementes[i+1] = sementes[mincli];
    sementes[mincli] = auxcli;
  }
  return;
}


/*
 * sem_ordena_dist_anteriores(); ordena o vetor de sementes por maior distancia
 * de todas as sementes anteriores.
 * Retorna: void
 */
void sem_ordena_dist_anteriores()
{
  register int i, j, k;
  prec_dist_t ddistancia = DIST_NEGATIVA;
  ap_cliente_t dsem = 0;
  ap_cliente_t auxcli;
  prec_dist_t soma_distancia;

  /* para cada semente de i+1 at� NS-1... */
  for(i = 0; i < num_sementes_no_vetor -2; i++) {
    /* avalie o melhor cliente prah por no local i+1... */
    for(j=i+1; j < num_sementes_no_vetor; j++) {
      soma_distancia = 0.0;
      for (k=0; k<=i; k++)
        soma_distancia += distancia[sementes[k]][sementes[j]];
      if (ddistancia < soma_distancia) {
        ddistancia = soma_distancia;
        dsem = j;
      }
    }
    /* e troque com a semente i+1 */
    auxcli = sementes[i+1];
    sementes[i+1] = sementes[dsem];
    sementes[dsem] = auxcli;
  }

  return;
}


int _quadrante(int x, int y)
{
  if (x>0 && y<0)
    return 4;
  else if (x<0 && y<0)
    return 3;
  else if (x<0 && y>0)
    return 2;

  return 1;
}

int _compara_angulo_horario (const void *u, const void *v)
{
  const int int_u = *((const int *) u);
  const int int_v = *((const int *) v);

  const double u1 = (const double) clientes[int_u].x - clientes[0].x; 
  const double u2 = (const double) clientes[int_u].y - clientes[0].y; 
  const double v1 = (const double) clientes[int_v].x - clientes[0].x;  
  const double v2 = (const double) clientes[int_v].y - clientes[0].y; 

  int resultado;

  resultado = _quadrante(u1,u2) - _quadrante (v1,v2);

  if (resultado == 0 ) {
    if ((u1) * (v2) > (u2) * (v1))
      resultado = -1;
    else if ((u1) * (v2) < (u2) * (v1))
      resultado = 1;
    else
      resultado = 0;
  }
  else {
    if (_quadrante(u1,u2) < _quadrante(v1,v2))
	resultado = -1;
    else
	resultado = 1;
  }
  
  return resultado;
}

/*
 * sem_ordena_var_horario(); ordena o vetor de sementes por varredura de angulos, no sentido horario.
 * Retorna: void
 */
void sem_ordena_var_horario( void )
{
  qsort(sementes, num_sementes_no_vetor, sizeof(int), _compara_angulo_horario);

  return;
}

int _compara_angulo_antihorario (const void *u, const void *v)
{
  const int int_u = *((const int *) u);
  const int int_v = *((const int *) v);

  const double u1 = (const double) clientes[int_u].x - clientes[0].x; 
  const double u2 = (const double) clientes[int_u].y - clientes[0].y; 
  const double v1 = (const double) clientes[int_v].x - clientes[0].x;  
  const double v2 = (const double) clientes[int_v].y - clientes[0].y; 

  int resultado;

  resultado = _quadrante(u1,u2) - _quadrante (v1,v2);

  if (resultado == 0 ) {
    if ((u1) * (v2) > (u2) * (v1))
      resultado = 1;
    else if ((u1) * (v2) < (u2) * (v1))
      resultado = -1;
    else
      resultado = 0;
  }
  else {
    if (_quadrante(u1,u2) < _quadrante(v1,v2))
	resultado = 1;
    else
	resultado = -1;
  }
  
  return resultado;
}

/*
 * sem_ordena_var_horario(); ordena o vetor de sementes por varredura de angulos, no sentido horario.
 * Retorna: void
 */
void sem_ordena_var_antihorario( void )
{
  qsort(sementes, num_sementes_no_vetor, sizeof(int), _compara_angulo_antihorario);

  return;
}

/*
 * sem_imprime_vetor(); imprime o vetor de sementes.
 * Retorna: void
 */

void sem_imprime_vetor( void )
{
  volatile int i;
  printf("Vetor de %d Sementes\n", num_sementes_no_vetor);
  for (i = 0; i < num_sementes_no_vetor; i++)
    printf(" %4d",sementes[i]);
  printf("\n");
}
