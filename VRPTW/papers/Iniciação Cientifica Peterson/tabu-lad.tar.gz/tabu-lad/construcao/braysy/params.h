
/* prevenindo dupla inclusao */
#ifndef PARAMS_GENERATE_H_
#define PARAMS_GENERATE_H_




/*
 * params_generate():
 * Gera parametros de acordo com o numero da solucao a ser criada
 */

void params_generate( int num_initial_solutions,
		      int *param_ord_seed,
		      float *param_alfa1,
		      float *param_alfa3,
		      float *param_distancia_granular);



#endif /* PARAMS_GENERATE_H_ */
