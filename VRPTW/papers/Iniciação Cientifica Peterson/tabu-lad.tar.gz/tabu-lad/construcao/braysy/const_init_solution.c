
#include "../../constantes.h"
#include "../../globals.h"
#include "../../auxiliares/auxiliares.h"

#include "const_sementes.h"
#include "const_insercao.h"
#include "const_lista_cli_prox.h"
#include "params.h"

#include "../../memory/memalloc.h"

#include "const_init_solution.h"

void const_init_solution( void )
{
  int cli, cli_anterior;
  prec_dist_t delta_distancia, custo;
  prec_time_t delta_tespera;
  

  /* fix initial value to variables of initial solution construction */
  zera_solucao();

  /* order seeds */
  switch (param_ord_seed) {
  case 1:
    sem_ordena_proximidade();
    break;
  case 2:
    sem_ordena_var_horario();
    break;
  case 3:
    sem_ordena_var_antihorario();
    break;
  }

  /* memory allocation for nearest clients lists from the route */
  lista_cli_prox = (int*) vvector(0,num_clientes-1, sizeof(int));
  lista_cli_prox_num_cli = 0;

  /* route construction itself */      
  while ( num_clientes_atendidos < num_clientes) {
    int sem_selecionada;  /* semente selecionada para a nova rota */
    
    /* seleciona semente */
    sem_selecionada = sem_seleciona_semente();
    
    /* limpa e atualiza a lista de clientes proximos */
    lista_cli_prox_num_cli = 0;
    lista_cli_prox_atualiza(sem_selecionada);
    
    /* cria uma nova rota */
    num_rotas++;
    rotas[num_rotas].num_clientes = 0;

   /* e insere a semente na primeira posicao */
   ins_executa(num_rotas, 0, sem_selecionada);

   ins_prox_cliente( num_rotas,
		     &cli,
		     &cli_anterior,
		     &delta_distancia,
		     &delta_tespera,
		     &custo );
      
   while (custo < DIST_INFINITO) {
     /* se ainda existem clientes vi�veis para essa rota, na lista
	de clientes proximos, entao */
     /* insere o cliente na rota */
     ins_executa(num_rotas, cli_anterior, cli);
     
     /* atualiza tempo de espera e distancia da rota */
     
     rotas[num_rotas].espera += delta_tespera;
     rotas[num_rotas].distancia += delta_distancia;
     
     /* apaga o cliente da lista de clientes proximos */
     
     lista_cli_prox_apaga(cli);
     
     /* atualiza lista de clientes proximos */
     
     lista_cli_prox_atualiza(cli);
     
     /* seleciona proximo cliente */
     ins_prox_cliente( num_rotas,
		       &cli,
		       &cli_anterior,
		       &delta_distancia,
		       &delta_tespera,
		       &custo );
   }
  }
  return;
}
