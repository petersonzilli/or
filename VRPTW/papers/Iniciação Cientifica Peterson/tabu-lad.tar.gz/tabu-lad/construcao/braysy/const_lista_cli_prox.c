#include "../../constantes.h"
#include "const_lista_cli_prox.h"

/* variaveis glogais */
#include "../../globals.h"

#include <stdio.h>
/* corpo das funcoes */


/*
 * lista_cli_prox_esta_na_lista();
 * Retorna: retorna se o cliente esta na lista de clientes proximos da rota
 *  atual
 */

Boolean lista_cli_prox_esta_na_lista( int cli )
{
  register int i;
  for(i = 0; i < lista_cli_prox_num_cli && lista_cli_prox[i] != cli; i++);
  return (i < lista_cli_prox_num_cli);
}


/*
 * lista_cli_prox_atualiza(); atualiza lista de clientes proximos da rota atual
 *  com a adicao do novo cliente 'cli'
 * Retorna: void
 */
void lista_cli_prox_atualiza( int cli )
{
  register int i;
  for(i = 1; i <= num_clientes; i++)
    if (distancia[cli][i] <= PARAM_DIST_GRANULAR * dist_cli_max
        && !(lista_cli_prox_esta_na_lista(i))
        && clientes[i].atendido == false)
      lista_cli_prox[lista_cli_prox_num_cli++] = i;
 
  return;
}

/*
 * lista_cli_prox_apaga(): apaga cliente 'cli' da lista de clientes proximos da
 *  rota atual
 * Retorna: void
 */
void lista_cli_prox_apaga( int cli )
{
  register int i;
  for(i = 0; lista_cli_prox[i] != cli && i < lista_cli_prox_num_cli; i++);
  
  while (i < lista_cli_prox_num_cli) {
    lista_cli_prox[i] = lista_cli_prox[i+1];
    i++;
  }
  
  lista_cli_prox_num_cli--;

  return;
}

/*
 * lista_cli_prox_imprime_vetor(); imprime o vetor de sementes.
 * Retorna: void
 */
void lista_cli_prox_imprime_vetor( void )
{
  register int i;
  printf("Lista de %d clientes proximos\n", lista_cli_prox_num_cli);
  for(i = 0; i < lista_cli_prox_num_cli; i++)
    printf ("%3d ", lista_cli_prox[i]);
  printf("\n");
  return;
}

