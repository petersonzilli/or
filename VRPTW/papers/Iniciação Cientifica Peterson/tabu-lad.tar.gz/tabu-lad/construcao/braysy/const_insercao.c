
#include "const_sementes.h"
#include "const_lista_cli_prox.h"
#include "const_insercao.h"

#include "../../constantes.h"
#include "../../macros.h"

#include "../../tipos.h"

/* variaveis globais */
#include "../../globals.h"

/*
 * ins_executa(); executa a insercao de um cliente nao roteado 'c' na posicao
 *  'i' da rota 'r' * Retorna: void.
 */
void ins_executa( int r, int cli_anterior, int c )
{
  register int i;
  int cli_aux;
  ap_cliente_t cli_aux1, cli_aux2;

  if (cli_anterior == 0)
    i = 0;
  else {
    cli_aux = rotas[r].inicio;
    for (i=1; cli_aux != cli_anterior; i++)
      cli_aux = clientes[cli_aux].c_dir;
  }

  if (rotas[r].num_clientes == 0) {  /* caso da semente */
    /* gerencia bordas*/
    rotas[r].inicio = c;
    rotas[r].fim = c;
    clientes[c].c_dir = 0;
    clientes[c].c_esq = 0;
    
    /* gerencia num de clientes na rota */
    rotas[r].demanda = 0.0;    /* vai ser atualizado antes de sair dessa funcao */
    rotas[r].num_clientes = 0;      /* vai ser atualizado antes de sair dessa funcao */
    rotas[r].espera = 0;       /* tempo de espera atual da rota */
    rotas[r].distancia = distancia[0][c] + distancia[c][0];  /* distancia atual da rota */
    
    /* gerenciando o b_time */
    /* calcula o tempo de inicio de servico para o cliente inserido */  
    clientes[c].a_time = clientes[0].t_ready + clientes[0].s_time + distancia[0][c] ;
    clientes[c].b_time = MAX( clientes[c].t_ready , clientes[c].a_time );
  }
  else {  /* insercao numa rota nao vazia */

    if (i == 0) { /* entao estamos inserindo no inicio da rota */
      int antigo_inicio;
      
      /* gerenciando bordas */
      antigo_inicio = rotas[r].inicio;
      clientes[antigo_inicio].c_esq = c;
      clientes[c].c_dir = antigo_inicio;
      clientes[c].c_esq = 0;
      rotas[r].inicio = c;
      
      /* gerenciando o b_time */
      /* calcula o tempo de inicio de servico para o cliente inserido */  
      clientes[c].a_time = clientes[0].t_ready + clientes[0].s_time + distancia[0][c] ;
      clientes[c].b_time = MAX( clientes[c].t_ready , clientes[c].a_time );
    }
    else if (i == rotas[r].num_clientes) { /* entao estamos inserindo no final da rota */
      int antigo_fim;
      
      /* gerenciando bordas */
      antigo_fim = rotas[r].fim;
      clientes[antigo_fim].c_dir = c;
      clientes[c].c_dir = 0;
      clientes[c].c_esq = antigo_fim;
      rotas[r].fim = c;
      
      /* gerenciando o b_time */
      /* calcula o tempo de inicio de servico para o cliente inserido */
      clientes[c].a_time = clientes[antigo_fim].b_time
          + clientes[antigo_fim].s_time
          + distancia[antigo_fim][c];
      clientes[c].b_time = MAX( clientes[c].t_ready , clientes[c].a_time );

    }
    else { /* estamos inserindo nem no inicio nem no final da rota, mas sim no meio dela */
      int iaux1;
      int cli_aux1, cli_aux2;
      
      /* corre at� o cliente anterior a insercao */
      cli_aux1 = rotas[r].inicio;
      for (iaux1=1; iaux1 < i; iaux1++)
        cli_aux1 = clientes[cli_aux1].c_dir;
      
      /* atualiza o cliaux2 */
      cli_aux2 = clientes[cli_aux1].c_dir;
      
      /* gerenciando bordas*/
      clientes[cli_aux1].c_dir = c;
      clientes[cli_aux2].c_esq = c;
      clientes[c].c_dir = cli_aux2;
      clientes[c].c_esq = cli_aux1;
      
      /* gerenciando o b_time */
      /* calcula o tempo de inicio de servico para o cliente inserido */  
      clientes[c].a_time = clientes[cli_aux1].b_time
          + clientes[cli_aux1].s_time
          + distancia[cli_aux1][c];
      clientes[c].b_time = MAX( clientes[c].t_ready , clientes[c].a_time );
    }

  }

  /* gerencia demanda */
  rotas[r].demanda += clientes[c].dem;
  rotas[r].num_clientes++;
  num_clientes_atendidos++;
  clientes[c].atendido = true;
  lista_cli_prox_apaga(c);

  /* gerenciando tempo de inicio de servico */
  cli_aux1 = c;
  cli_aux2 = clientes[cli_aux1].c_dir;
  
  while (cli_aux2 != 0) {
    clientes[cli_aux2].a_time = clientes[cli_aux1].b_time
      + clientes[cli_aux1].s_time
      + distancia[cli_aux1][cli_aux2];
    clientes[cli_aux2].b_time = MAX( clientes[cli_aux2].t_ready , clientes[cli_aux2].a_time );
    
    cli_aux1 = cli_aux2;
    cli_aux2 = clientes[cli_aux1].c_dir;
  }

  return;
}

/*
 * ins_avalia_distancia ();
 * Retorna: o diferencial da distancia da insercao do cliente 'cli' na posicao
 *  'pos'
 */
prec_dist_t ins_avalia_distancia ( int r, int cli_anterior, int cli )
{
  ap_cliente_t cli_posterior;
  prec_dist_t delta_distancia = 0.0;
  
  /* colocando o cliente 0 para apontar a direita para o primeiro cliente da rota */
  clientes[0].c_dir = rotas[r].inicio;

  cli_posterior = clientes[cli_anterior].c_dir;
  
  delta_distancia = distancia[cli_anterior][cli]
    + distancia[cli][cli_posterior]
    - distancia[cli_anterior][cli_posterior];
  
  return delta_distancia;
}


/*
 * ins_avalia_tempo_espera();
 * Retorna: o diferencial de tempo de espera da insercao do cliente 'cli' na
 * posicao posterior ao cli_anterior da rota 'r'
 * eh possivel na otica da janela de tempo.
 */
float ins_avalia_tempo_espera( int r, int cli_anterior, int cli )
{
  register int cli_aux2; /* cli_posterior */
  ap_cliente_t cli_aux1; /* cliente atual */
  prec_time_t delta_tespera;
  prec_time_t t_inicio;
  
  /* fazendo o deposito apontar para o inicio da rota */
  clientes[0].c_dir = rotas[r].inicio;
  clientes[0].b_time = clientes[0].t_ready;
  

  /**********************************************/
  /* AVALIA para a borda (cliente_anterior,cli) */
  if (cli_anterior == 0) {
    delta_tespera = 0.0;
    t_inicio = clientes[cli].t_ready;
  }
  else {
    /* tempo de chegada de cli */
    t_inicio = clientes[cli_anterior].b_time
      + clientes[cli_anterior].s_time
      + distancia[cli_anterior][cli];
    
    /* tempo de espera em cli */
    delta_tespera = MAX(t_inicio, clientes[cli].t_ready) - t_inicio;
    
    /* tempo de inicio em cli */
    t_inicio = MAX (t_inicio, clientes[cli].t_ready);
  }
  
  /********************************************************/
  /* AVALIA para as bordas restantes, at� o final da rota */
  cli_aux1 = cli;
  cli_aux2 = clientes[cli_anterior].c_dir;

  while (cli_aux2 != 0) {
    /* tempo de chegada em cli_aux2 */
    t_inicio = t_inicio
      + clientes[cli_aux1].s_time
      + distancia[cli_aux1][cli_aux2];
    
    /* tempo de espera em cli_aux2 */
    delta_tespera += (MAX (t_inicio, clientes[cli_aux2].t_ready) - t_inicio)
      - (clientes[cli_aux2].b_time - clientes[cli_aux2].a_time);
    
    /* tempo de inicio em cli_aux2 */
    t_inicio = MAX (t_inicio, clientes[cli_aux2].t_ready);
    
    /* atualiza ponteiros */
    cli_aux1 = cli_aux2;
    cli_aux2 = clientes[cli_aux1].c_dir;
  }
  
  return delta_tespera;
}



/*
 * ins_avalia_TW();
 * Retorna: 'true' se a insercao do cliente 'c' na posicao 'pos' da rota 'r'  eh
 *  possivel na otica da janela de tempo.
 */
Boolean ins_avalia_TW(int r, int cli_anterior, int cli)
{
  register int cli_aux2;
  prec_time_t b_time;
  ap_cliente_t cli_aux1;
  
  /* Gambiarra! para poder usar a borda ZERO sem maiores modificacoes! */
  clientes[0].c_dir = rotas[r].inicio;
  clientes[0].b_time = clientes[0].t_ready;
    
  /* tempo de atendimento do cliente 'cli' inserido */
  b_time = MAX( clientes[cli].t_ready
		, clientes[cli_anterior].b_time
		+ clientes[cli_anterior].s_time
		+ distancia[cli_anterior][cli]);
  
  if (b_time > clientes[cli].t_due ) return false;
      
  
  /* setando cli como cliente anterior e i+1 como o cliente atual */
  cli_aux1 = cli;
  cli_aux2 = clientes[cli_anterior].c_dir;
  
  /* enquando nao chegou ao final da rota... */
  while (cli_aux2 != 0 ) {
    /* o novo tempo de servico levando em conta somente a viagem do anterior
       ateh o atual */
    
    b_time = MAX( clientes[cli_aux2].t_ready
		  , b_time
		  + clientes[cli_aux1].s_time
		  + distancia[cli_aux1][cli_aux2]);
    
    /* updating mechanism*/
    if (b_time <= clientes[cli_aux2].b_time) return true;

    /* janela de tempo furada! */
    if (b_time > clientes[cli_aux2].t_due) return false;
    
    cli_aux1 = cli_aux2;
    cli_aux2 = clientes[cli_aux2].c_dir;
  }
  
  /*nao encontrou janela de tempo alguma fora do lugar.*/
  return true;
}


/*
 * ins_avalia_capacidade();
 * Retorna: 'true' se a insercao do cliente 'c' na rota 'r' eh possivel na otica
 *  da capacidade.
 */
Boolean ins_avalia_capacidade(int r, int c)
{
  return ( (rotas[r].demanda + clientes[c].dem) <= capacidade) ;
}


/*
 * ins_prox_cliente();
 * Retorna: o melhor cliente e a melhor posicao para se inserir na rota em
 *  construcao
 */
void ins_prox_cliente( int r,
                       int *cli,
                       int *cli_anterior,
                       prec_dist_t *delta_distancia,
                       prec_time_t *delta_tespera,
                       prec_dist_t *custo )
{
  register int aux_cli;
  int aux_cli_anterior = 0;
  prec_dist_t aux_delta_distancia = 0.0;
  prec_time_t aux_delta_tespera = 0.0;
  prec_dist_t aux_custo = DIST_INFINITO;
  
  *custo = DIST_INFINITO;
  
  for (aux_cli = 0; aux_cli < lista_cli_prox_num_cli; aux_cli++) { /* para todos os clientes na lista de clientes proximos */
    ins_melhor_insercao_na_rota(r, lista_cli_prox[aux_cli], &aux_cli_anterior,
                                &aux_delta_distancia, &aux_delta_tespera, &aux_custo);
    if (aux_custo < *custo) {
      *cli = lista_cli_prox[aux_cli];
      *cli_anterior = aux_cli_anterior;
      *delta_distancia = aux_delta_distancia;
      *delta_tespera = aux_delta_tespera;
      *custo = aux_custo;
    }
  }
  
  return;  
}

                       
/*
 * ins_melhor_insercao_na_rota();
 * Retorna: a melhor insercao do cliente cli na rota em construcao
 */
void ins_melhor_insercao_na_rota( int r,
                                  int cli,
                                  int *cli_anterior,
                                  prec_dist_t *delta_distancia,
                                  prec_time_t *delta_tespera,
                                  prec_dist_t *custo )
{
  register int aux_cli_anterior;  

  prec_dist_t aux_delta_distancia = 0.0;
  prec_time_t aux_delta_tespera = 0.0;
  prec_dist_t aux_custo = DIST_INFINITO;
  
  *custo = DIST_INFINITO;
  
  /*testa insercao do cliente 'cli' na primeira borda */
  ins_avalia_posicao(r, cli, 0, &aux_delta_distancia, &aux_delta_tespera, &aux_custo);
  *cli_anterior = 0;
  *delta_distancia = aux_delta_distancia;
  *delta_tespera = aux_delta_tespera;
  *custo = aux_custo;

  /* testa insercao do cliente 'cli' nas n bordas [c1,cn] */
  aux_cli_anterior = rotas[r].inicio;
  while (aux_cli_anterior != 0) { /* para todas as bordas nas rotas */
    ins_avalia_posicao(r, cli, aux_cli_anterior, &aux_delta_distancia, &aux_delta_tespera, &aux_custo);
    if (aux_custo < *custo) {
      *cli_anterior = aux_cli_anterior;
      *delta_distancia = aux_delta_distancia;
      *delta_tespera = aux_delta_tespera;
      *custo = aux_custo;
    }
    aux_cli_anterior = clientes[aux_cli_anterior].c_dir;
  }
  
  return;
}
                                  

/*
 * ins_avalia_posicao();
 * Retorna: o custo da insercao do cliente 'cli' na posicao seguinte ao 'cli_anterior'
 */
void ins_avalia_posicao( int r,
                         int cli,
                         int cli_anterior,
                         prec_dist_t *delta_distancia,
                         prec_time_t *delta_tespera,
                         prec_dist_t *custo )
{
  *delta_distancia = 0.0;
  *delta_tespera = 0.0;
  *custo = DIST_INFINITO;
  
  /* verifica viabilidade da insercao */
  if (ins_avalia_capacidade(r, cli) && ins_avalia_TW(r, cli_anterior, cli)) {
    *delta_distancia = ins_avalia_distancia (r, cli_anterior, cli);
    *delta_tespera = ins_avalia_tempo_espera( r, cli_anterior, cli);
    
    /* colocar aqui os outros componentes do custo!! */
    *custo = PARAM_ALFA1 * (*delta_distancia)
      + (1-PARAM_ALFA1) * (*delta_tespera)
      - PARAM_ALFA3 * distancia[0][cli];

  }
  
  return;
}
