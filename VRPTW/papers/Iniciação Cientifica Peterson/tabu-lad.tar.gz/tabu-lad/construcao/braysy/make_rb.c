#include <stdio.h>

#include "../../constantes.h"
#include "../../globals.h"
#include "make_rb.h"


void make_rb(solution_backup_t *vec_solutions, int *num_backup_solutions)
{
  int i_aux1, i_aux2, i_aux3, i_aux4, i_aux5;
  Boolean solucao_igual;

  /* number of routes with the smallest number of routes */
  i_aux1 = 0; /* numero de solucoes diferentes das anteriores criadas com o numero minimo de rotas*/
  i_aux4 = 0; /* numero de solucoes criadas com o numero minimo de rotas */
  i_aux5 = 0; /* auxiliar para achar solucoes iguais as anteriores */


#if (ORDENA_ROTAS)
  /* get the smallest number of routes of the solutions created */
  i_aux2 = SINT_INFINITO;
  for(i_aux3 = 0; i_aux3 < *num_backup_solutions; i_aux3++) {
    if (vec_solutions[i_aux3].num_rotas < i_aux2) {
      i_aux2 = vec_solutions[i_aux3].num_rotas;
    }
  }
  
  
  /* selection solutions with min number of routes */
  for(i_aux3 = 0; i_aux3 < *num_backup_solutions; i_aux3++) {
    if (vec_solutions[i_aux3].num_rotas == i_aux2) {
      i_aux4++;
      solucao_igual = false;
      for (i_aux5 = 0; i_aux5 < i_aux1 && !(solucao_igual); i_aux5++) {
        solucao_igual = (vec_solutions[i_aux3].distancia == vec_solutions[i_aux5].distancia);
      }
      if (!(solucao_igual)) {
        vec_solutions[i_aux1] = vec_solutions[i_aux3];
        i_aux1++;
      }
    }
  }
#endif /*(ORDENA_ROTAS)*/

#if (ORDENA_DISTANCIA)
  {
    volatile int i, j, k;
    prec_dist_t aux_dist = DIST_INFINITO;
    
    int aux_num_rotas;         
    prec_dist_t aux_distancia;       
    int *aux_rotas;            
    int *aux_clientes;         


    for(i = 0; i < *num_backup_solutions; i++) {
      /* para cada posicao de 0 a numsolutions */
      k = i;
      for(j = i; j < *num_backup_solutions; j++) {
      /* seleciona a menor disntancia de i ateh numsolutions */
        if (vec_solutions[j].distancia < aux_dist) {
          k = j;
        }
      }
      /* troca k com a posicao i */
      aux_rotas = vec_solutions[k].rotas;
      aux_clientes = vec_solutions[k].clientes;
      aux_distancia = vec_solutions[k].distancia;
      aux_num_rotas = vec_solutions[k].num_rotas;
      
      vec_solutions[k].rotas = vec_solutions[i].rotas;
      vec_solutions[k].clientes = vec_solutions[i].clientes;
      vec_solutions[k].distancia = vec_solutions[i].distancia;
      vec_solutions[k].num_rotas = vec_solutions[i].num_rotas;
      
      vec_solutions[i].rotas = aux_rotas;
      vec_solutions[i].clientes = aux_clientes;
      vec_solutions[i].distancia = aux_distancia;
      vec_solutions[i].num_rotas = aux_num_rotas;
    }
  }
#endif  
  
  /* TODO *** free unused memory ***
  
    for(i_aux2=i_aux1; i_aux2 < num_backup_solutions; i_aux2++)
    solution_free(vec_solutions[i_aux2]);
 
  */
  
  /* imprimindo dados da geracao e eliminacao de rotas*/
    /*
    printf("numero minimo de rotas na construcao  = %6d\n",i_aux2);
    printf("menor distancia = %7.2f\n", vec_solutions[1].distancia);
    printf("numero de solucoes pesquisadas        = %6d\n",(*num_backup_solutions)+1);
    printf("numero de solucoes c minimo de rotas  = %6d\n",i_aux4);
    printf("numero de solucoes diferentes em dist = %6d\n",i_aux1);
    */
  /* uptating the number of backup solutions*/
  *num_backup_solutions = i_aux1;
 
}
