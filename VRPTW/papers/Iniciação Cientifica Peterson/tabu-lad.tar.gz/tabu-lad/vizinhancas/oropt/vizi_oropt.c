
#include "../../constantes.h"
#include "../../macros.h"
#include "../../auxiliares/auxiliares.h"

#include "../../testset/testes.h"

#include "vizi_oropt.h"

#include "../../globals.h"


/* executa o movimento oropt */
void vizi_oropt_exec( int r1,
                      int c10,
                      int c11,
                      int c20,
                      int c21,
                      int c30,
                      int c31 )
{
  clientes[c10].c_dir =  c21;
  clientes[c21].c_esq =  c10;
  
  clientes[c30].c_dir =  c11;
  clientes[c11].c_esq =  c30;
  
  clientes[c20].c_dir =  c31;
  clientes[c31].c_esq =  c20;

  if (c10 == 0) rotas[r1].inicio = c21;
  if (c31 == 0) rotas[r1].fim = c20;

  atualiza_rota(r1);
        
  return;
}

float vizi_oropt_eval( int c10,
                       int c11,
                       int c20,
                       int c21,
                       int c30,
                       int c31,
                       Boolean *tw,
                       prec_dist_t  *ddist,
                       prec_time_t *dtespera )
{

  /* avaliando o movimento */
  *tw = vizi_oropt_eval_tw( c10,
                            c11,
                            c20,
                            c21,
                            c30,
                            c31 );
  if (*tw  == false) return DIST_INFINITO;
  
  
  *ddist = vizi_oropt_eval_ddist( c10,
                                  c11,
                                  c20,
                                  c21,
                                  c30,
                                  c31 );

  *dtespera = vizi_oropt_eval_dtespera( c10,
                                        c11,
                                        c20,
                                        c21,
                                        c30,
                                        c31 );  

  /* retorna o custo do movimento */
  return ( *ddist + (OROPT_ALFA2 * distancia[c11][c30]) - ( OROPT_ALFA3 * clientes[c11].t_ready )) ;
}
                       

float vizi_oropt_eval_ddist( int c10,
                             int c11,
                             int c20,
                             int c21,
                             int c30,
                             int c31 )
{
  return (distancia[c10][c21]
         + distancia[c20][c31]
         + distancia[c30][c11]
         - distancia[c10][c11]
         - distancia[c20][c21]
         - distancia[c30][c31]);
}


Boolean vizi_oropt_eval_tw( int c10,
                            int c11,
                            int c20,
                            int c21,
                            int c30,
                            int c31 )
{
  ap_cliente_t aux_cli; /* auxiliar para os loops */
  prec_time_t tempo; /* nossa variavel de tempo */

  /** verificando restricoes de janela de tempo para a rota 1 **/
  /* tempo de chegada no cliente c21 */
  tempo = clientes[c10].b_time
    + clientes[c10].s_time
    + distancia[c10][c21];

  /* testa janelas de tempo */
  /* if ( tempo > clientes[c21].t_due ) return false; essa comparacao e inutil.. sempre vai ser menor. */
#ifdef HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[c21].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em (borda_c20-1) */
  tempo = MAX( tempo, clientes[c21].t_ready );

  /* no inicio do laco, a variavel tempo sempre tem o valor do inicio de servico do cliente c21 */
  /* testa de c21.c_dir ate c30 */
  aux_cli = c21;
  while (aux_cli != c30) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[clientes[aux_cli].c_dir].b_time ) return true; */
/**************************************************************************************************/

#ifdef HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }


  /* temos o tempo de inicio de servico em c30 */
  /* a variavel tempo tem o de inicio de servico no cliente c30 e queremos testar o de c11*/
  tempo = tempo
    + clientes[c30].s_time
    + distancia[c30][c11];

  /* testa janelas de tempo */
  if ( tempo > clientes[c11].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[c11].b_time ) return true; */
/**************************************************************************************************/

#ifdef HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[c11].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em c11 */
  tempo = MAX( tempo, clientes[c11].t_ready );

  /* testa tempo de inicio de servico para os clientes apos c11 */
  aux_cli = c11;
  while (aux_cli != c20) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[clientes[aux_cli].c_dir].b_time ) return true; */
/**************************************************************************************************/

#ifdef HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }

  /* temos o tempo de inicio de servico em c20 */
  /* a variavel tempo tem o de inicio de servico no cliente c30 e queremos testar o de c31*/
  tempo = tempo
    + clientes[c20].s_time
    + distancia[c20][c31];

  /* testa janelas de tempo */
  if ( tempo > clientes[c31].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[c31].b_time ) return true; */
/**************************************************************************************************/

#ifdef HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[c31].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em c11 */
  tempo = MAX( tempo, clientes[c31].t_ready );

  /* testa tempo de inicio de servico para os clientes apos c11 */
  aux_cli = c31;

  /* testa sempre do cliente logo depois ao aux_cli !! olhemos o comentario abaixo*/
  while (aux_cli != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[clientes[aux_cli].c_dir].b_time ) return true; */
/**************************************************************************************************/

#ifdef HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }
  
  /* estah tudo certo entao */
  return true;
}

float vizi_oropt_eval_dtespera( int c10,
                                int c11,
                                int c20,
                                int c21,
                                int c30,
                                int c31 )
{
  return 0.0;
}

void vizi_oropt_best_move_rota( int r1,
                               move_oropt *move )
{
  volatile int i;
  ap_cliente_t c10, c11, c20, c21, c30, c31; /* os clientes da borda */
  
  ap_cliente_t bordas1_fim;
  
  int caixa; /* tamanho da caixa */
  
  Boolean tw;
  prec_dist_t custo, ddist;
  prec_time_t dtespera;
  
  move->custo = DIST_INFINITO;
  
  if (rotas[r1].num_clientes < 1) return; /* pula rota eliminada */
  
  for (caixa = 1; caixa <= 3; caixa++) {
    if (rotas[r1].num_clientes < caixa) return; 
    
    /* pega o cliente final da borda da caixa */
    bordas1_fim = rotas[r1].fim;
    for (i=1; i<caixa; i++) {
      bordas1_fim = clientes[bordas1_fim].c_esq;
    }
      
    for (c11 = rotas[r1].inicio; c11 != bordas1_fim; c11 = clientes[c11].c_dir) {
      /* atualiza as bordas da caixa */
      c10 = clientes[c11].c_esq;
      
      c20 = c11;
      for (i=1; i<caixa;i++) {
        c20 = clientes[c20].c_dir;
      }
      
      c21 = clientes[c20].c_dir;
      
      for (c30 = c21; c30 != 0; c30 = clientes[c30].c_dir) {
        c31 = clientes[c30].c_dir;
      
        /* testes
          printf(">>> movimento oropt %d %d %d %d %d %d\n", c10, c11, c20, c21, c30, c31);
          continue;
        */
        
        custo = vizi_oropt_eval(c10, c11, c20, c21, c30, c31, &tw, &ddist, &dtespera);
#if ZERO
        /* nao permite movimentos com valor zero */
        if ( (int) custo != 0) {
#endif          
          if (tw) {
            if (custo < move->custo) {
              move->custo = custo;
              move->ddist = ddist;
              move->dtespera = dtespera;
              move->r1 = r1;
              move->c10 = c10;
              move->c11 = c11;
              move->c20 = c20;
              move->c21 = c21;
              move->c30 = c30;
              move->c31 = c31;
            }
          }
#if ZERO
        }
#endif
      
      }
    }
  }

  return;
}
