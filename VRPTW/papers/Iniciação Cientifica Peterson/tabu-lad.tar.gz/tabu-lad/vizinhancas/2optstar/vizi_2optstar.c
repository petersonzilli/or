
#include "../../constantes.h"  
#include "../../macros.h"
#include "../../auxiliares/auxiliares.h"
#include "../../testset/testes.h"

#include "../../globals.h"

#include "vizi_2optstar.h"

float vizi_2opt_s_eval_ddist( int borda_c10,
                              int borda_c11,
                              int borda_c20,
                              int borda_c21 )
{
  prec_dist_t ddist;
  ddist = distancia[borda_c10][borda_c21]
         - distancia[borda_c10][borda_c11];
  ddist += distancia[borda_c20][borda_c11]           
           - distancia[borda_c20][borda_c21];
  return ddist;
}

float vizi_2opt_s_eval_dtespera( int borda_c10,
                                 int borda_c11,
                                 int borda_c20,
                                 int borda_c21 )
{
  ap_cliente_t aux_cli; /* auxiliar para os loops */
  prec_time_t tempo; /* nossa variavel de tempo */
  prec_dist_t dtespera;

  /** verificando tempo de espera para a rota 1 **/
  /* tempo de chegada no cliente c21 */
  tempo = clientes[borda_c10].b_time
    + clientes[borda_c10].s_time
    + distancia[borda_c10][borda_c21];

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
  tempo = MAX( tempo, clientes[borda_c21].t_ready );
  
  dtespera = tempo - clientes[borda_c21].b_time;

  /* testa tempo de espera para os clientes apos c21, sobre rota 2 */
  /* no inicio do laco, a variavel tempo sempre tem o valor do inicio de servico do cliente borda_c21 */
  aux_cli = borda_c21;
  while (clientes[aux_cli].c_dir != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], nao verificamos o tempo de espera do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    dtespera += tempo - clientes[clientes[aux_cli].c_dir].b_time;
    
    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }


  /** verificando tempo de espera para a rota 2 **/
  /* para o cliente borda*/
  /* tempo de chegada no cliente c11 */
  tempo = clientes[borda_c20].b_time
    + clientes[borda_c20].s_time
    + distancia[borda_c20][borda_c11];

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c11 */
  tempo = MAX( tempo, clientes[borda_c11].t_ready );

  dtespera += tempo - clientes[borda_c11].b_time;
  
  /* testa tempo de inicio de servico para os clientes apos c11, sobre rota 1 */
  aux_cli = borda_c11;  

  while (clientes[aux_cli].c_dir != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], nao verificamos o tempo de espera do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    dtespera += tempo - clientes[clientes[aux_cli].c_dir].b_time;
    
    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }
  
  return dtespera;
}

Boolean vizi_2opt_s_eval_tw( int borda_c10,
                             int borda_c11,
                             int borda_c20,
                             int borda_c21 )

{
  ap_cliente_t aux_cli; /* auxiliar para os loops */
  prec_time_t tempo; /* nossa variavel de tempo */

  /** verificando restricoes de janela de tempo para a rota 1 **/
  /* tempo de chegada no cliente c21 */
  tempo = clientes[borda_c10].b_time
    + clientes[borda_c10].s_time
    + distancia[borda_c10][borda_c21];

  /* testa janelas de tempo */
  if ( tempo > clientes[borda_c21].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[borda_c21].b_time ) return true;*/
/**************************************************************************************************/

#if HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[borda_c21].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
  tempo = MAX( tempo, clientes[borda_c21].t_ready );

  /* testa tempo de inicio de servico para os clientes apos c21, sobre rota 2 */
  /* no inicio do laco, a variavel tempo sempre tem o valor do inicio de servico do cliente borda_c21 */
  aux_cli = borda_c21;
  while (aux_cli != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[clientes[aux_cli].c_dir].b_time ) return true;*/
/**************************************************************************************************/
#if HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }


  /** verificando restricoes de janela de tempo para a rota 2 **/
  /* verificando a tw para o cliente borda*/
  /* tempo de chegada no cliente c11 */
  tempo = clientes[borda_c20].b_time
    + clientes[borda_c20].s_time
    + distancia[borda_c20][borda_c11];

  /* testa janelas de tempo */
  if ( tempo > clientes[borda_c11].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*    if ( tempo <= clientes[borda_c11].b_time ) return true;*/
/**************************************************************************************************/

#if HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[borda_c11].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c11 */
  tempo = MAX( tempo, clientes[borda_c11].t_ready );

  /* testa tempo de inicio de servico para os clientes apos c11, sobre rota 1 */
  aux_cli = borda_c11;  

  while (aux_cli != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
/**************************************************************************************************/
/* TEST Updating Mechanisms !!! */
/*   if ( tempo <= clientes[clientes[aux_cli].c_dir].b_time ) return true;*/
/**************************************************************************************************/

#if HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }
  
  /* estah tudo certo entao */
  return true;
}

Boolean vizi_2opt_s_eval_cap( int r1,
                              int borda_c11,
                              int r2,
                              int borda_c21 )
{
  Boolean feasible = true;
  prec_dem_t aux_cap1 = 0.0;
  prec_dem_t aux_cap2 = 0.0;
  ap_cliente_t aux_cli;
 
  aux_cli = borda_c11;
  while (aux_cli != 0) {
    aux_cap1 += clientes[aux_cli].dem;
    aux_cli = clientes[aux_cli].c_dir;
  }

  aux_cli = borda_c21;
  while (aux_cli != 0) {
    aux_cap2 += clientes[aux_cli].dem;
    aux_cli = clientes[aux_cli].c_dir;
  }

  /* se a primeira jah der errado entao nao avalia a capacidade na segunda rota */  
  if ((rotas[r1].demanda + aux_cap2 - aux_cap1) > capacidade)
    feasible = false;
  else if ((rotas[r2].demanda + aux_cap1 - aux_cap2) > capacidade)
    feasible = false;
  
  return feasible;
}

float vizi_2opt_s_eval( int r1,
                        int indx_c1,
                        int r2,
                        int indx_c2,
                        Boolean *tw,
                        Boolean *cap,
                        prec_dist_t *ddist,
                        prec_time_t *dtespera )
{
  volatile int i;
  ap_cliente_t borda_c10, borda_c11, borda_c20, borda_c21; /* os clientes da borda */

  /* inicializa cliente borda_c11 com o numero do cliente na posicao indx_c1*/
  borda_c11 = rotas[r1].inicio;
  for (i = 0; i < indx_c1; i++) {
    /*vai at� o cliente c1*/
    borda_c11 = clientes[borda_c11].c_dir;
  }

  /* inicializa cliente borda_c21 com o numero do cliente na posicao indx_c2 */
  borda_c21 = rotas[r2].inicio;
  for (i=0; i < indx_c2; i++) {
    /*vai at� o cliente c1*/
    borda_c21 = clientes[borda_c21].c_dir;
  }

  /* setando valor inicial da borda_c10 */
  clientes[0].c_esq = rotas[r1].fim;
  borda_c10 = clientes[borda_c11].c_esq;

  /* setando valor inicial da borda_c20 */
  clientes[0].c_esq = rotas[r2].fim;
  borda_c20 = clientes[borda_c21].c_esq;


  /* avaliando o movimento */
  *tw = vizi_2opt_s_eval_tw( borda_c10,
                             borda_c11,
                             borda_c20,
                             borda_c21 );
  if (*tw  == false) return DIST_INFINITO;
  
  
  *cap = vizi_2opt_s_eval_cap( r1,
                               borda_c11,
                               r2,
                               borda_c21 );
  if (*cap == false) return DIST_INFINITO;

  *ddist = vizi_2opt_s_eval_ddist( borda_c10,
                                  borda_c11,
                                  borda_c20,
                                  borda_c21 );

  *dtespera = vizi_2opt_s_eval_dtespera( borda_c10,
                                        borda_c11,
                                        borda_c20,
                                        borda_c21 );  
  /* TODO: funcao de custo mais elaborada */
  /* retorna o custo do movimento */
  return (*ddist);
}

#define ELIMINOU_EXEC ((indx_c1==0 && indx_c2 == rotas[r2].num_clientes) || (indx_c1 == rotas[r1].num_clientes && indx_c2 == 0))
void vizi_2opt_s_exec( int r1,
                       int indx_c1,
                       int r2,
                       int indx_c2 )
{
  volatile int i;
  ap_cliente_t borda_c10, borda_c11, borda_c20, borda_c21; /* os clientes da borda */

  /* inicializa cliente borda_c11 com o numero do cliente na posicao indx_c1*/
  borda_c11 = rotas[r1].inicio;
  for (i = 0; i < indx_c1; i++) {
    /*vai at� o cliente c1*/
    borda_c11 = clientes[borda_c11].c_dir;
  }

  /* inicializa cliente borda_c21 com o numero do cliente na posicao indx_c2 */
  borda_c21 = rotas[r2].inicio;
  for (i=0; i < indx_c2; i++) {
    /*vai at� o cliente c1*/
    borda_c21 = clientes[borda_c21].c_dir;
  }

  /* setando valor inicial da borda_c10 */
  clientes[0].c_esq = rotas[r1].fim;
  borda_c10 = clientes[borda_c11].c_esq;

  /* setando valor inicial da borda_c20 */
  clientes[0].c_esq = rotas[r2].fim;
  borda_c20 = clientes[borda_c21].c_esq;

  if (ELIMINOU_EXEC) num_rotas--;
  
  /* atualiza os ponteiros internos */
  clientes[borda_c10].c_dir = borda_c21;
  clientes[borda_c21].c_esq = borda_c10;
  clientes[borda_c20].c_dir = borda_c11;
  clientes[borda_c11].c_esq = borda_c20;

  /* se necessario atualiza o ponteiro de inicio das rotas r1 e r2 */
  if (borda_c10 == 0) rotas[r1].inicio = borda_c21;
  if (borda_c20 == 0) rotas[r2].inicio = borda_c11;
  
  /* atualiza o fim das rotas*/
  i = rotas[r1].fim;
  
  if ( borda_c11 == 0 ) {
    /*if ( borda_c21 == 0 ) {
      nop; 
    }*/
    if ( borda_c21 != 0 ) {
      rotas[r1].fim = rotas[r2].fim;
      rotas[r2].fim = borda_c20;
    }
  } else { /* borda_c11 != 0 */
    if ( borda_c21 == 0 ) {
      rotas[r1].fim = borda_c10;
      rotas[r2].fim = i;      
    } else {
      rotas[r1].fim = rotas[r2].fim;
      rotas[r2].fim = i;
    }  
  }
     
  /* atualizando numero de clientes */
  i = rotas[r1].num_clientes;
  rotas[r1].num_clientes = indx_c1
    + rotas[r2].num_clientes
    - indx_c2;
  rotas[r2].num_clientes = indx_c2
    + i
    - indx_c1;
    
  /* calcula tempos de chegada, etc. */

  atualiza_rota(r1);
  atualiza_rota(r2);

  return;
}

void vizi_2opt_s_exec_tabu( int r1,
                            int indx_c1,
                            int r2,
                            int indx_c2,
                            int **(*tabulist),
                            int iter)
{
  int tabuiter;
  
  tabuiter = iter + TABU_TENURE;
  
  /* executa a 2opt */
  vizi_2opt_s_exec( r1, indx_c1, r2, indx_c2 );
  
  /* atualiza status tabu */
  (*tabulist)[r1][1] = tabuiter;
  (*tabulist)[r2][2] = tabuiter;  
  
  return;
}


#define INUTIL ((c1==0 && c2 == 0) || (c1 == rotas[r1].num_clientes && c2 == rotas[r2].num_clientes))
void vizi_2opt_s_best_move_desc( move_2opt_s *move )
{
  register int r1, c1, r2, c2;
  Boolean tw, cap;
  prec_dist_t custo, ddist;
  prec_time_t dtespera;
  
  move->custo = DIST_INFINITO;
  
  for (r1 = 1; r1 < num_clientes; r1++) { 
    if (rotas[r1].num_clientes < 1) continue; /* pula rotas eliminadas */
    for (r2 = r1+1; r2 <= num_clientes; r2++) {
      if (rotas[r2].num_clientes < 1) continue; /* pula rotas eliminadas */
      /* para todos as combinacoes de dois tours */
      
      for (c1 = 0; c1 <= rotas[r1].num_clientes; c1++) {
	for (c2 = 0; c2 <= rotas[r2].num_clientes; c2++) {
	  if (INUTIL) continue; /* pula avaliacoes inuteis */
          custo = vizi_2opt_s_eval(r1, c1, r2, c2, &tw, &cap, &ddist, &dtespera);
#if ZERO
	  /* nao permite movimentos com valor zero */
	  if ( (int) custo != 0) {
#endif          
	    if (tw && cap) {
	      if (custo < move->custo) {
	        move->custo = custo;
                move->ddist = ddist;
                move->dtespera = dtespera;
	        move->r1 = r1;
	        move->indx_c1 = c1;
	        move->r2 = r2;
	        move->indx_c2 = c2;
	      }
            }
#if ZERO
	  }
#endif
	}
      }
    }
  }
  return;
}

#define ELIMINOU_ROTAS ((c1==0 && c2 == rotas[r2].num_clientes) || (c1 == rotas[r1].num_clientes && c2 == 0))
void vizi_2opt_s_best_move_desc_rotas( move_2opt_s *move )
{
  register int r1, c1, r2, c2;
  Boolean tw, cap;
  prec_dist_t custo, ddist;
  prec_time_t dtespera;
  
  move->custo = DIST_INFINITO;
  
  for (r1 = 1; r1 < num_clientes; r1++) { 
    if (rotas[r1].num_clientes < 1) continue; /* pula rotas eliminadas */
    for (r2 = r1+1; r2 <= num_clientes; r2++) {
      if (rotas[r2].num_clientes < 1) continue; /* pula rotas eliminadas */
      /* para todos as combinacoes de dois tours */
      
      for (c1 = 0; c1 <= rotas[r1].num_clientes; c1++) {
	for (c2 = 0; c2 <= rotas[r2].num_clientes; c2++) {
	  if (INUTIL) continue; /* pula avaliacoes inuteis */
          custo = vizi_2opt_s_eval(r1, c1, r2, c2, &tw, &cap, &ddist, &dtespera);
#if ZERO
	  /* nao permite movimentos com valor zero */
	  if ( (int) custo != 0) {
#endif          
          custo += (num_rotas - ((ELIMINOU_ROTAS) ? 1 : 0)) * VIZI_PESO_ROTA;
            if (tw && cap) {
              if (custo < move->custo) {
                move->custo = custo;
                move->ddist = ddist;
                move->dtespera = dtespera;
                move->num_rotas = num_rotas - ((ELIMINOU_ROTAS) ? 1 : 0) ;
                move->r1 = r1;
                move->indx_c1 = c1;
                move->r2 = r2;
                move->indx_c2 = c2;
              }
            }
#if ZERO
	  }
#endif
	}
      }
    }
  }
  return;
}



void vizi_2opt_s_best_move_tabu( move_2opt_s *move,
                                 prec_dist_t c_curr,
                                 prec_dist_t c_best,
                                 int** tabulist,
                                 int iter )
{
  register int r1, c1, r2, c2;
  Boolean tw, cap;
  prec_dist_t custo, ddist;
  prec_time_t dtespera;
  
  move->custo = DIST_INFINITO;
  
  for (r1 = 1; r1 < num_clientes; r1++) { 
    if (rotas[r1].num_clientes < 1) continue; /* pula rotas eliminadas */
    for (r2 = r1+1; r2 <= num_clientes; r2++) {
      if (rotas[r2].num_clientes < 1) continue; /* pula rotas eliminadas */
      /* para todos as combinacoes de dois tours */
      
      for (c1 = 0; c1 <= rotas[r1].num_clientes; c1++) {
	for (c2 = 0; c2 <= rotas[r2].num_clientes; c2++) {
	  if (INUTIL) continue; /* pula avaliacoes inuteis */
          custo = vizi_2opt_s_eval(r1, c1, r2, c2, &tw, &cap, &ddist, &dtespera);
#if ZERO
	  /* nao permite movimentos com valor zero */
	  if ( (int) custo != 0) {
#endif          
            /*custo += (num_rotas - ((ELIMINOU_ROTAS) ? 1 : 0)) * VIZI_PESO_ROTA;*/
            if (tw && cap) {
              if (custo < move->custo) {
                if (((tabulist[r1][1] < iter) && (tabulist[r2][2] < iter)) || ((c_curr + ddist) < c_best)  ) {
                  move->custo = custo;
                  move->ddist = ddist;
                  move->dtespera = dtespera;
                  move->num_rotas = num_rotas - ((ELIMINOU_ROTAS) ? 1 : 0) ;
                  move->r1 = r1;
                  move->indx_c1 = c1;
                  move->r2 = r2;
                  move->indx_c2 = c2;
                }
              }
            }
            /*custo -= (num_rotas - ((ELIMINOU_ROTAS) ? 1 : 0)) * VIZI_PESO_ROTA;*/
#if ZERO
	  }
#endif
	}
      }
    }
  }
  return;
}
