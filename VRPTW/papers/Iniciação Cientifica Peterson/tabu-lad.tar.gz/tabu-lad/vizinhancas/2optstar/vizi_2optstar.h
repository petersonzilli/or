
#ifndef VIZI_2OPTSTAR_H_
#define VIZI_2OPTSTAR_H_

#define FIS 0 /* set 1 para implementar a first improving strategy */
#define ZERO 1 /* set 1 para desabilitar movimentos de valor zero*/

#include "../../tipos.h"

typedef struct move_2opt_s {
        prec_dist_t custo;
        prec_dist_t ddist;
        prec_time_t dtespera;
        int num_rotas;
        int r1;
        int indx_c1;
        int r2;
        int indx_c2;
} move_2opt_s;

float vizi_2opt_s_eval_ddist( int borda_c10,
                              int borda_c11,
                              int borda_c20,
                              int borda_c21 );

float vizi_2opt_s_eval_dtespera( int borda_c10,
                                 int borda_c11,
                                 int borda_c20,
                                 int borda_c21 );

Boolean vizi_2opt_s_eval_tw( int borda_c10,
                             int borda_c11,
                             int borda_c20,
                             int borda_c21 );


Boolean vizi_2opt_s_eval_cap( int r1,
                              int borda_c11,
                              int r2,
                              int borda_c21 );

float vizi_2opt_s_eval( int r1,
                        int indx_c1,
                        int r2,
                        int indx_c2,
                        Boolean *tw,
                        Boolean *cap,
                        prec_dist_t *ddist,
                        prec_time_t *dtespera );

void vizi_2opt_s_exec( int r1,
                       int indx_c1,
                       int r2,
                       int indx_c2 );

void vizi_2opt_s_exec_tabu( int r1,
                            int indx_c1,
                            int r2,
                            int indx_c2,
                            int **(*tabulist),
                            int iter );


void vizi_2opt_s_best_move_desc( move_2opt_s *move );

void vizi_2opt_s_best_move_desc_rotas( move_2opt_s *move );

void vizi_2opt_s_best_move_tabu( move_2opt_s *move,
                                 prec_dist_t c_curr,
                                 prec_dist_t c_best,
                                 int **tabulist,
                                 int iter );

#endif /* _VIZI_2OPTSTAR_H_ */
