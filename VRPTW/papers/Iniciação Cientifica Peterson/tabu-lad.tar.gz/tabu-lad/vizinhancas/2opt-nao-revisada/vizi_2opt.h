
#ifndef VIZI_2OPT_H
#define VIZI_2OPT_H

#define FIS 0 /* set=1 para implementar a first improving strategy */

#include "../../tipos.h"

typedef struct move_2opt {
  float custo;
  float ddist;
  float dtespera;
  int r1;
  int indx_c1;
  int indx_c2;
} move_2opt;

/* executa o movimento 2opt */
void vizi_2opt_executa( int r1,
                        int indx_c1,
                        int indx_c2 );

/* avalia a 2opt de c1 a c2  sobre a rota r1 */
float vizi_2opt_eval( int r1,
                      int indx_c1,
                      int indx_c2,
                      Boolean *tw,
                      float *ddist,
                      float *dtespera );


float vizi_2opt_eval_dtespera( int borda_c10,
                               int borda_c11,
                               int borda_c20,
                               int borda_c21 );
                               
float vizi_2opt_eval_ddist( int borda_c10,
                            int borda_c11,
                            int borda_c20,
                            int borda_c21 );

Boolean vizi_2opt_eval_tw( int borda_c10,
                           int borda_c11,
                           int borda_c20,
                           int borda_c21 );

void vizi_2opt_best_move_rota( int r1,
                               move_2opt *move );

#endif
