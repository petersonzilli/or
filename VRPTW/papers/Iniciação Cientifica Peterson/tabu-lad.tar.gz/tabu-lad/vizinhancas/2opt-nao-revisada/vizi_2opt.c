
#include "vizi_2opt.h"

#include "../../constantes.h"
#include "../../macros.h"
#include "../../auxiliares/auxiliares.h"

#include "../../testset/testes.h"



#include "../../auxiliares/globals.h"


void vizi_2opt_executa( int r1,
                        int indx_c1,
                        int indx_c2 )
{
  volatile int i;
  ap_cliente_t borda_c10, borda_c11, borda_c20, borda_c21; /* os clientes da borda */
  ap_cliente_t aux_cli1, aux;

  /* inicializa cliente borda_c11 com o numero do cliente na posicao indx_c1*/
  borda_c11 = rotas[r1].inicio;
  for (i = 1; i < indx_c1; i++) {
    /*vai at� o cliente c1*/
    borda_c11 = clientes[borda_c11].c_dir;
  }

  /* inicializa cliente borda_c21 com o numero do cliente na posicao indx_c2 */
  borda_c21 = rotas[r1].inicio;
  for (i=0; i < indx_c2; i++) {
    /*vai at� o cliente c1*/
    borda_c21 = clientes[borda_c21].c_dir;
  }

  /* setando valor inicial da borda_c10 */
  /* setando valor inicial da borda_c20 */
  clientes[0].c_esq = rotas[r1].fim;
  borda_c10 = clientes[borda_c11].c_esq;
  borda_c20 = clientes[borda_c21].c_esq;


  /* inverte as bordas internas.. */   

  /* atualiza volta */
  aux_cli1 = borda_c11;
  while (aux_cli1 != borda_c21) {
    /* volta */
    clientes[aux_cli1].c_esq = clientes[aux_cli1].c_dir;
    aux_cli1 = clientes[aux_cli1].c_dir;
  }

  /* usa volta para atualizar ida... blah! */
  aux = borda_c11;
  aux_cli1 = clientes[borda_c11].c_dir;
  while (aux_cli1 != borda_c21) {
    clientes[aux_cli1].c_dir = aux;
    aux = aux_cli1;
    aux_cli1 = clientes[aux_cli1].c_esq;
  }  

    
  /* bordas externas */
  clientes[borda_c10].c_dir = borda_c20;
  clientes[borda_c20].c_esq = borda_c10;
  clientes[borda_c11].c_dir = borda_c21;
  clientes[borda_c21].c_esq = borda_c11;

  if (borda_c10 == 0) rotas[r1].inicio = borda_c20;
  if (borda_c21 == 0) rotas[r1].fim = borda_c11;

  atualiza_rota(r1);
        
  return;
}

/* avalia a 2opt de c1 a c2  sobre a rota r1 */
float vizi_2opt_eval( int r1,
                      int indx_c1,
                      int indx_c2,
                      Boolean *tw,
                      float *ddist,
                      float *dtespera )
{
  volatile int i;
  ap_cliente_t borda_c10, borda_c11, borda_c20, borda_c21; /* os clientes da borda */

  /* inicializa cliente borda_c11 com o numero do cliente na posicao indx_c1*/
  borda_c11 = rotas[r1].inicio;
  for (i = 1; i < indx_c1; i++) {
    /*vai at� o cliente c1*/
    borda_c11 = clientes[borda_c11].c_dir;
  }

  /* inicializa cliente borda_c21 com o numero do cliente na posicao indx_c2 */
  borda_c21 = rotas[r1].inicio;
  for (i=0; i < indx_c2; i++) {
    /*vai at� o cliente c1*/
    borda_c21 = clientes[borda_c21].c_dir;
  }

  /* setando valor inicial da borda_c10 */
  /* setando valor inicial da borda_c20 */
  clientes[0].c_esq = rotas[r1].fim;
  borda_c10 = clientes[borda_c11].c_esq;
  borda_c20 = clientes[borda_c21].c_esq;


  /* avaliando o movimento */
  *tw = vizi_2opt_eval_tw( borda_c10,
                           borda_c11,
                           borda_c20,
                           borda_c21 );
  if (*tw  == false) return DIST_INFINITO;
  
  
  *ddist = vizi_2opt_eval_ddist( borda_c10,
                                 borda_c11,
                                 borda_c20,
                                 borda_c21 );

  *dtespera = vizi_2opt_eval_dtespera( borda_c10,
                                       borda_c11,
                                       borda_c20,
                                       borda_c21 );  

  /* retorna o custo do movimento */
  return (*ddist);
}


float vizi_2opt_eval_dtespera(int borda_c10,
                               int borda_c11,
                               int borda_c20,
                               int borda_c21 )
{
  return 0.0;
}
                               
float vizi_2opt_eval_ddist( int borda_c10,
                            int borda_c11,
                            int borda_c20,
                            int borda_c21 )
{
  return (distancia[borda_c10][borda_c20]
         + distancia[borda_c11][borda_c21]
         - distancia[borda_c10][borda_c11]
         - distancia[borda_c20][borda_c21]);
}

Boolean vizi_2opt_eval_tw( int borda_c10,
                           int borda_c11,
                           int borda_c20,
                           int borda_c21 )
{
  ap_cliente_t aux_cli; /* auxiliar para os loops */
  float tempo; /* nossa variavel de tempo */

  /** verificando restricoes de janela de tempo para a rota 1 **/
  /* tempo de chegada no cliente c20 */
  tempo = clientes[borda_c10].b_time
    + clientes[borda_c10].s_time
    + distancia[borda_c10][borda_c20];

  /* testa janelas de tempo */
  if ( tempo > clientes[borda_c20].t_due ) return false;
#ifdef HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[borda_c20].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em (borda_c20-1) */
  tempo = MAX( tempo, clientes[borda_c20].t_ready );

  /* testa tempo de inicio de servico para os clientes antes de c20, sobre a subrota revertida */
  /* no inicio do laco, a variavel tempo sempre tem o valor do inicio de servico do cliente borda_c20 */
  aux_cli = borda_c20;
  while (aux_cli != borda_c11) {
    /* tempo de chegada no cliente [aux_cli - 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_esq];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_esq].t_due ) return false;
#ifdef HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_esq].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_esq].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_esq;
  }


  /** verificando restricoes de janela de tempo para o primeiro cliente depois da subrota revertida **/
  /* a variavel tempo tem o de inicio de servico no cliente c11 */
  tempo = tempo
    + clientes[borda_c11].s_time
    + distancia[borda_c11][borda_c21];

  /* testa janelas de tempo */
  if ( tempo > clientes[borda_c21].t_due ) return false;
#ifdef HARD_TW /* caso das janelas de tempo hard */
  if ( tempo < clientes[borda_c21].t_ready ) return false;
#endif

  /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c11 */
  tempo = MAX( tempo, clientes[borda_c21].t_ready );

  /* testa tempo de inicio de servico para os clientes apos c21 */
  aux_cli = borda_c21;

  /* testa sempre do cliente logo depois ao aux_cli !! olhemos o comentario abaixo*/
  while (aux_cli != 0) {
    /* tempo de chegada no cliente [aux_cli + 1], e por isso verificamos a TW do deposito no final */
    tempo = tempo
      + clientes[aux_cli].s_time
      + distancia[aux_cli][clientes[aux_cli].c_dir];
    
    /* testa janelas de tempo */
    if ( tempo > clientes[clientes[aux_cli].c_dir].t_due ) return false;
#ifdef HARD_TW /* caso das janelas de tempo hard */
    if ( tempo < clientes[clientes[aux_cli].c_dir].t_ready ) return false;
#endif
    
    /* atualiza a nossa variavel de tempo com o tempo de inicio de servico em borda_c21 */
    tempo = MAX( tempo, clientes[clientes[aux_cli].c_dir].t_ready );

    /* atualiza ponteiro */
    aux_cli = clientes[aux_cli].c_dir;
  }
  
  /* estah tudo certo entao */
  return true;
}

void vizi_2opt_best_move_rota( int r1,
                               move_2opt *move )
{
  register int c1, c2;
  Boolean tw;
  float custo, ddist, dtespera;
  
  move->custo = DIST_INFINITO;
  
  if (rotas[r1].num_clientes < 1) return; /* pula rotas eliminada */
  
  for (c1 = 1; c1 < rotas[r1].num_clientes; c1++) {
    for (c2 = c1+1; c2 <= rotas[r1].num_clientes; c2++) {
      custo = vizi_2opt_eval(r1, c1, c2, &tw, &ddist, &dtespera);
#if ZERO
      /* nao permite movimentos com valor zero */
      if ( (int) custo != 0) {
#endif          
        if (tw) {
          if (custo < move->custo) {
            move->custo = custo;
            move->ddist = ddist;
            move->dtespera = dtespera;
            move->r1 = r1;
            move->indx_c1 = c1;
            move->indx_c2 = c2;
          }
        }
#if ZERO
      }
#endif
    }
  }
  return;
}
