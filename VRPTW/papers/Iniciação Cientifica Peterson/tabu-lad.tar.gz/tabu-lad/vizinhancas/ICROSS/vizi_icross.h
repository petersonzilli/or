
#ifndef VIZI_ICROSS_H_
#define VIZI_ICROSS_H_

#define FIS 0 /* set=1 para implementar a first improving strategy */

#include "../../tipos.h"

typedef struct move_oropt {
  prec_dist_t custo;
  prec_dist_t ddist;
  prec_time_t dtespera;
  int r1;
  int c10;
  int c11;
  int c20;
  int c21;
  int c30;
  int c31;    
} move_oropt;

/* executa o movimento oropt */
void vizi_oropt_exec( int r1,
                      int c10,
                      int c11,
                      int c20,
                      int c21,
                      int c30,
                      int c31 );

float vizi_oropt_eval( int c10,
                       int c11,
                       int c20,
                       int c21,
                       int c30,
                       int c31,
                       Boolean *tw,
                       prec_dist_t *ddist,
                       prec_time_t *dtespera );

float vizi_oropt_eval_ddist( int c10,
                             int c11,
                             int c20,
                             int c21,
                             int c30,
                             int c31 );

Boolean vizi_oropt_eval_tw( int c10,
                            int c11,
                            int c20,
                            int c21,
                            int c30,
                            int c31 );

float vizi_oropt_eval_dtespera( int c10,
                                int c11,
                                int c20,
                                int c21,
                                int c30,
                                int c31 );

void vizi_oropt_best_move_rota( int r1,
                               move_oropt *move );

#endif /* VIZI_ICROSS_H_ */
