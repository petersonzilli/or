./main instancias2/s101.txt 
./main instancias2/s102.txt 
./main instancias2/s103.txt 
./main instancias2/s104.txt 
