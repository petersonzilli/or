/*
** principal.h
** 
** Made by Peterson Katagiri Zilli
** 
** Started on  Fri Sep 23 21:12:08 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 21:43:00 2005 Peterson Katagiri Zilli
*/

#ifndef   	PRINCIPAL_H_
#define   	PRINCIPAL_H_



#endif 	    /* !PRINCIPAL_H_ */
