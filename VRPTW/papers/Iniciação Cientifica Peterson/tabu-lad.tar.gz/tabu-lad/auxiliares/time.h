/*
** time.h
** 
** Made by Peterson Katagiri Zilli
** 
** Started on  Fri Sep 23 23:18:11 2005 Peterson Katagiri Zilli
** Last update Fri Sep 23 23:22:19 2005 Peterson Katagiri Zilli
*/


/* Rotinas para medicao de  tempo. Elas foram implementadas pelo Ionut
 * Aaron (Brown,GSIA) */

/* usage of the CPUTIME timing routine:
  ===================================

  struct rusage ruse;
  double t0 = CPUTIME(ruse);
  ...
  double t1 = CPUTIME(ruse);
  printf("CPU time: %f secs.\n", t1-t0);
*/


#ifndef __SYSTEM_TIME_H
#define __SYSTEM_TIME_H

/* Ionut Aron, ia@cs.brown.edu (1999-2001)
 * created: August, 1999
 * last updated: December 20, 2001
 */

#include <sys/resource.h>
#include <sys/types.h>
#include <time.h>

extern int getrusage();

/*
 * this macro produces a time equal to the one produced by clock(),
 * but does not suffer from the wraparound problem of clock()
 */

#define CPUTIME(ruse) (\
 getrusage(RUSAGE_SELF,&ruse),\
 ruse.ru_utime.tv_sec + ruse.ru_stime.tv_sec + \
 1e-6 * (ruse.ru_utime.tv_usec + ruse.ru_stime.tv_usec)\
)


/* variavel global usada na medicao de tempo */
struct rusage ruse;

#endif
