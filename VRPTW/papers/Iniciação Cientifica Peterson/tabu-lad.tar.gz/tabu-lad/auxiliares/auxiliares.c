
/* includes */

#include <stdio.h>
#include <stdlib.h>

#include "../tipos.h"
#include "../globals.h"
#include "../macros.h"

/* corpo das funcoes  */
 
/*
 * nerror(): sai do programa com mensagem de erro.
 * Retorna: void.
 */
void nrerror( char *error_text )
{
  fprintf(stderr,"\n%s\n",error_text);
  fprintf(stderr,"... Saindo Para o Sistema ...\n");
  exit(1);
}

/*
 * zera_solucao(): limpa os rastros da solucao antiga
 */
void zera_solucao ( void )
{
  volatile int i;
  
  for (i=1;i <= num_clientes; i++) {
    clientes[i].c_dir = 0;
    clientes[i].c_esq = 0;
    clientes[i].a_time = 0.0;
    clientes[i].b_time = 0.0;
    clientes[i].atendido = false;
    rotas[i].inicio = 0;
    rotas[i].fim = 0;
    rotas[i].num_clientes = 0;
    rotas[i].demanda = 0.0;       
    rotas[i].distancia = 0.0;
  }
  
  num_rotas = 0;
  num_clientes_atendidos = 0;
  lista_cli_prox_num_cli = 0;
  
  return;
}

/*
 * imprime_rotas(): imprime os tours que estao armazenados.
 * Retorna: void.
 */
void imprime_rotas( void )
{
  register int i, contador, contador_cli;     /* contadores auxiliares */
  ap_cliente_t ap_cli_aux; /* apontador auxiliar para clientes */

  contador = contador_cli = 0;

  /* printf("*** Imprimindo Solucao Atual ***\n"); */
  for(i = 1; i <= num_clientes; i++) {
    if (rotas[i].num_clientes > 0) { /* pula rotas vazias */
      contador++;
      ap_cli_aux = rotas[i].inicio;
      printf ("t%3d <0-%d-", i, (int) clientes[ap_cli_aux].num);
      contador_cli++;
      
      ap_cli_aux = clientes[ap_cli_aux].c_dir;
      while (ap_cli_aux != 0) {
	printf ("%d-", (int) clientes[ap_cli_aux].num);
        contador_cli++;
	ap_cli_aux = clientes[ap_cli_aux].c_dir;
      }
      printf ("0>\n");
      /*printf ("0>\t<numcli=%3d>\t<dem=%7.2f>\t<dist=%7.2f>\n", rotas[i].num_clientes, rotas[i].demanda,rotas[i].distancia);*/
      /*printf ("0>\t<inicio=%3d>\t<fim=%3d>\n", rotas[i].inicio, rotas[i].fim);*/
    }
  }
  /* printf("*** Total de %d rotas, %d clientes. *** - %s\n", contador,contador_cli, in_arquivo); */

  return;
}

void imprime_rota( int r1 )
{
  ap_cliente_t aux;
  if (rotas[r1].num_clientes < 1) return;
  
  aux = rotas[r1].inicio;
  printf("(0-");
  while (aux != 0 ) {
    printf("%d-",aux);
    aux = clientes[aux].c_dir;
  }
  printf("0)\n");
  
  aux = rotas[r1].fim;
  printf("(0-");
  while (aux != 0 ) {
    printf("%d-",aux);
    aux = clientes[aux].c_esq;
  }
  printf("0)\n");
  
  return;
}

void calcula_inicio_de_servico( int r1 )
{
  int aux_cli0, aux_cli1;
  prec_time_t tempo = 0.0;
  
  if (rotas[r1].num_clientes < 1 ) return;
  
  aux_cli0 = 0;
  aux_cli1 = rotas[r1].inicio;
  
  /* certificamos que o cliente zero inicia servico no tempo zero */
  clientes[0].b_time = 0.0;
    
  while (aux_cli1 != 0) {
    tempo = MAX( tempo,
                 clientes[aux_cli0].b_time 
                   + clientes[aux_cli0].s_time 
                   + distancia[aux_cli0][aux_cli1]);
    clientes[aux_cli1].a_time = tempo;
    
    tempo = MAX( tempo,
                 clientes[aux_cli1].t_ready);
    clientes[aux_cli1].b_time = tempo;
    
    aux_cli0 = aux_cli1;
    aux_cli1 = clientes[aux_cli1].c_dir;
  }
  
  return;
}


float retorna_distancia( void )
{
  int r1, aux_cli1, aux_cli2;
  prec_dist_t total = 0.0;
  
  for (r1=1; r1<=num_clientes; r1++) {
    if (rotas[r1].num_clientes < 1 ) continue;
  
    aux_cli1 = 0;
    aux_cli2 = rotas[r1].inicio;

    while (aux_cli2 != 0) {
      total += distancia[aux_cli1][aux_cli2];
      aux_cli1 = aux_cli2;
      aux_cli2 = clientes[aux_cli2].c_dir;
    }
      
    total += distancia[rotas[r1].fim][0];
  }
  
  return total;
}

void calcula_demanda( int r1 )
{
  int aux_cli1;
  prec_dem_t total = 0.0;
  
  if (rotas[r1].num_clientes < 1 ) return;
  
  aux_cli1 = rotas[r1].inicio;
    
  while (aux_cli1 != 0) {
    total += clientes[aux_cli1].dem;
    aux_cli1 = clientes[aux_cli1].c_dir;
  }
  
  rotas[r1].demanda = total;
  
  return;
}

void calcula_distancia( int r1 )
{
  int aux_cli1, aux_cli2;
  prec_dist_t total = 0.0;
  
  if (rotas[r1].num_clientes < 1 ) return;
  
  aux_cli1 = 0;
  aux_cli2 = rotas[r1].inicio;
    
  while (aux_cli2 != 0) {
    total += distancia[aux_cli1][aux_cli2];
    aux_cli1 = aux_cli2;
    aux_cli2 = clientes[aux_cli2].c_dir;
  }
      
  total += distancia[rotas[r1].fim][0];
  
  rotas[r1].distancia = total;
  
  return;
}


void calcula_tespera( int r1 )
{
  int aux_cli1;
  prec_time_t total = 0.0;
  
  if (rotas[r1].num_clientes < 1 ) return;
  
  aux_cli1 = rotas[r1].inicio;
    
  while (aux_cli1 != 0) {
    total += clientes[aux_cli1].a_time - clientes[aux_cli1].b_time;
    aux_cli1 = clientes[aux_cli1].c_dir;
  }
  
  rotas[r1].espera = total;
  
  return;
}

void atualiza_rota( int r1 )
{
  calcula_demanda( r1 );
  calcula_distancia( r1 );
  calcula_inicio_de_servico( r1 );
  calcula_tespera( r1 );

  return;
}

