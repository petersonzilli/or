
/* prevenindo dupla inclusao */
#ifndef _FUNCAUXILIARES_H_
#define _FUNCAUXILIARES_H_

/* includes locais */
#include "../tipos.h"

/* prototipos das funcoes */

void nrerror( char *error_text );
void zera_solucao ( void );
void imprime_rotas( void );
void imprime_rota( int r1 );
void calcula_inicio_de_servico( int r1 );
float retorna_distancia( void );
void calcula_demanda( int r1 );
void calcula_distancia( int r1 );
void calcula_tespera( int r1 );
void atualiza_rota( int r1 );

#endif /* _FUNCAUXILIARES_H_ */
