
#ifndef _TESTES_H_
#define _TESTES_H_

#include <stdio.h>
#include "../tipos.h"

#define TSTtrace (printf("passou arquivo: %s funcao: %s linha: %d\n",__FILE__,__PRETTY_FUNCTION__,__LINE__))

/* prototipos das fun�oes de teste */

void TSTtw(void);
void TSTcapacidade(void);
void TSTdistancia(void);

#endif /* _TESTES_H_ */
