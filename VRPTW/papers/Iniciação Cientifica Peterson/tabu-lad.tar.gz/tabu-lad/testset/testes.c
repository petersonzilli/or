
#include "testes.h"
#include "../constantes.h"

/* variaveis globais */
#include "../globals.h"

/* testa se todos os tempos de inicio de servico atendem as janelas de tempo. */
void TSTtw(void)
{
  register int i;
  Boolean vtw = true;
  
  for (i = 1; i <= num_clientes; i++) {
    if (clientes[i].b_time > clientes[i].t_due){
      vtw = false;
      break;
    }
    
#ifdef HARD_TW
    if (clientes[i].b_time < clientes[i].t_ready) {
      vtw = false;
      break;
    }
#endif
    
  }
  
  printf("*** Clientes %sViolam Janela de Tempo - %s\n",vtw?"Nao ":"", in_arquivo);
  
  return;
}

/* testa se todos os tours atendem ao limite de capacidade. */
void TSTcapacidade(void)
{
  register int i;
  Boolean cap = true;
  int aux_cli;
  float tourcap;
  
  for( i = 1; i <= num_clientes; i++) {
    if (rotas[i].num_clientes < 1) continue;
    tourcap = 0.0;
    aux_cli = rotas[i].inicio;
    
    /* tourcap = capacidade total atual do tour */
    while (aux_cli != 0) {
      tourcap += clientes[aux_cli].dem;
      aux_cli = clientes[aux_cli].c_dir;
      if (tourcap > capacidade) {
        cap = false;
        break;
      }
    }
    
    if (tourcap > capacidade) break;
  }
  
  printf("*** Tours %sExcedem Capacidade dos Veiculos - %s\n",cap?"Nao ":"",in_arquivo);
  
  return ;
}

/* verifica a soma total de distancias. */
void TSTdistancia(void)
{
  register int i;
  int aux_cli1, aux_cli2;
  float total = 0.0;
  
  for( i = 1; i <= num_clientes; i++) {
    if (rotas[i].num_clientes < 1 ) continue;
    aux_cli1 = 0;
    aux_cli2 = rotas[i].inicio;
    
    /* tourcap = capacidade total atual do tour */
    while (aux_cli2 != 0) {
      total += distancia[aux_cli1][aux_cli2];
      aux_cli1 = aux_cli2;
      aux_cli2 = clientes[aux_cli2].c_dir;
    }
    
    total += distancia[rotas[i].fim][0];
  }
  
  printf("*** Distancia Total = %10.2f - %s\n",total, in_arquivo);
  
  return ;
}
